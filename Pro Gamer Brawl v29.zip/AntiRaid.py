import sqlite3
import time
import threading
import colorama


plrcheck = 5 # for every ? seconds check if there is bot accounts
clubcheck = 600 # for every ? seconds check if there is bot clubs

# SETTINGS
defgold = 100
defgems = 0
# SETTINGS END

# other
def log(msg: str):
    print(f"\033[92m[AntiDDoS]: {msg}\033[0m")
# other end

log(f"1. anti account spam: every {plrcheck} second all spam accounts will get deleted\n2. anti club spam: every {clubcheck} second all spam clans will get deleted")

pConn = sqlite3.connect("database/Player/plr.db", check_same_thread=False)
pCur = pConn.cursor()   

def delclubs():
    while True:
        cConn = sqlite3.connect("database/Club/clubs.db")
        chConn = sqlite3.connect("database/Club/chats.db")

        cCur = cConn.cursor()
        chCur = chConn.cursor()

        cCur.execute("SELECT clubID, trophies FROM clubs")
        rows = cCur.fetchall()

        dltdclubs = 0
        for club_id, trophies in rows:
            try:
                trophyvalue = float(str(trophies).strip())
            except:
                trophyvalue = -1

            if trophyvalue == 0:
                chCur.execute("DELETE FROM chats WHERE clubID = ?", (club_id,))
                cCur.execute("DELETE FROM clubs WHERE clubID = ?", (club_id,))
                pCur.execute("UPDATE plrs SET clubID = 0, clubRole = 0 WHERE clubID = ?", (club_id,))
                dltdclubs += 1

        if dltdclubs > 0:
            log(f"deleted {dltdclubs} clubs")

        cConn.commit()
        chConn.commit()
        pConn.commit()
        cConn.close()
        chConn.close()
        time.sleep(clubcheck)
def delbotplr():
    while True:
        pCur.execute("SELECT token, trophies, gold, gems FROM plrs")
        players = pCur.fetchall()
        dltdplrs = 0
        
        for token, trophies, gold, gems in players:
            try:
                trophyvalue = float(str(trophies).strip())
                goldvalue = float(str(gold).strip())
                gemsvalue = float(str(gems).strip())
            except:
                trophyvalue = -1
                goldvalue = -1
                gemsvalue = -1

            if trophyvalue == 0 and goldvalue <= defgold and gemsvalue <= defgems:
                pCur.execute("DELETE FROM plrs WHERE token = ?", (token,))
                dltdplrs += 1

        if dltdplrs > 0:
            log(f"deleted {dltdplrs} plrs")

        pConn.commit()
        time.sleep(plrcheck)

threading.Thread(target=delclubs, daemon=True).start()
threading.Thread(target=delbotplr, daemon=True).start()

# thread active
while True:
    time.sleep(1)
