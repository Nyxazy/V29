#Update! added extra rewards

import json
import random
import time
import os
import math

timer = 86400
timer2 = 3600# reset timer
howmuchoffers = 5 # how much skin
howmuchextra = 6 # gives 5 extra rewards

def log(msg: str):
    print(f"\033[92m[AUTO SHOP]: {msg}\033[0m")

def logerr(msg: str):
    print(f"\033[31m[AUTO SHOP]: {msg}\033[0m")

log(f"auto shop is successfully loaded! Every {timer} seconds, {howmuchoffers+howmuchextra} offers will come to shop.")

skins = {
    29: (29, 0, 1), 159: (149, 0, 1), 15: (29, 0, 1), 79: (149, 0, 1),
    47: (79, 0, 1), 2: (29, 0, 1), 103: (29, 0, 1), 25: (79, 0, 1),
    64: (149, 0, 1), 102: (79, 0, 1), 44: (149, 0, 1), 123: (149, 0, 1),
    163: (149, 0, 1), 58: (79, 0, 1), 91: (149, 0, 1), 57: (149, 0, 1),
    97: (299, 0, 1), 160: (149, 0, 1), 94: (299, 0, 1), 98: (79, 0, 1),
    99: (149, 0, 1), 109: (29, 0, 1), 167: (29, 0, 1), 28: (79, 0, 1),
    30: (149, 0, 1), 128: (149, 0, 1), 71: (149, 0, 1), 27: (29, 0, 1),
    59: (149, 0, 1), 92: (79, 0, 1), 158: (79, 0, 1), 26: (149, 0, 1),
    68: (149, 0, 1), 130: (79, 0, 1), 88: (79, 0, 1), 165: (79, 0, 1),
    93: (79, 0, 1), 104: (79, 59, 1), 132: (79, 0, 1), 108: (79, 0, 1),
    120: (29, 0, 1), 147: (149, 0, 1), 45: (79, 0, 1), 125: (79, 0, 1),
    139: (29, 0, 1), 111: (29, 0, 1), 50: (149, 79, 1), 75: (149, 0, 1),
    117: (79, 0, 1), 137: (29, 0, 1), 152: (29, 0, 1), 11: (79, 0, 1),
    96: (149, 0, 1), 110: (149, 0, 1), 126: (79, 0, 1), 131: (79, 0, 1),
    20: (79, 0, 1), 49: (299, 0, 1), 95: (299, 0, 1), 100: (79, 0, 1),
    101: (149, 0, 1), 118: (149, 0, 1), 203: (149, 0, 1), 177: (29, 0, 1),290: (79, 0, 1),296: (79, 0, 1),297: (149, 0, 1),288: (49, 0, 1),287: (49, 0, 1),286: (299, 0, 1),285: (29, 0, 1),284: (199, 0, 1),283: (29, 0, 1),292: (79, 0, 1),276: (199, 0, 1),274: (299, 0, 1),272: (79, 0, 1),271: (79, 0, 1),270: (149, 0, 1),269: (199, 0, 1),263: (149, 0, 1),262: (79, 0, 1),260: (149, 0, 1),259: (149, 0, 1),257: (149, 0, 1),256: (199, 0, 1),255: (79, 0, 1),249: (149, 0, 1),248: (199, 0, 1),247: (149, 0, 1),246: (199, 0, 1),245: (199, 0, 1),242: (149, 0, 1),241: (149, 0, 1),240: (299, 0, 1),239: (149, 0, 1)
}

def addof(d, dID, title, cost, ID, bID, M, sd):
    d[dID] = {
            'ID': [ID, 0, 0],
            'OfferTitle': title,
            'SkinID': [0, 0, 0],
            'Cost': cost,
            'OldCost': 0,
            'Multiplier': [M, 0, 0],
            'BrawlerID': [bID, 0, 0],
            'RequiredBrawler': [0, 0, 0],
            'RequiredSkin': [0, 0, 0],
            'OfferView': 0,
            'ETType': 0,
            'ETMultiplier': 0,
            'Timer': timer2,
            'OfferBGR': 'offer_generic',
            'ShopType': 0,
            'ShopDisplay': sd, #1=daily deals 0=normal offer
            'OfferView': 1,
            'WhoBuyed': []
        }

def refreshoffers():
    choices = random.sample(list(skins.keys()), min(howmuchoffers, len(skins)))
    data = {}
    for idx, skin_id in enumerate(choices):
        data[str(idx)] = {
            'ID': [4, 0, 0],
            'OfferTitle': f'SKIN',
            'SkinID': [skin_id, 0, 0],
            'Cost': skins[skin_id][0],
            'OldCost': skins[skin_id][1],
            'Multiplier': [skins[skin_id][2], 0, 0],
            'BrawlerID': [0, 0, 0],
            'RequiredBrawler': [0, 0, 0],
            'RequiredSkin': [0, 0, 0],
            'OfferView': 0,
            'ETType': 0,
            'ETMultiplier': 0,
            'Timer': timer,
            'OfferBGR': 'offer_generic',
            'ShopType': 0,
            'ShopDisplay': 0,
            'WhoBuyed': []
        }
    for i in range(howmuchextra):
        if random.randint(0, 100) > 50:
            extra_id = str(len(data))
            choosed=random.randint(1,10)
            if choosed==1: # Power points
                addof(data, extra_id, "POWER POINTS", 0, 8, random.randint(0, 39), random.randint(0, 300), 1)
            elif choosed==2: # Coins
                addof(data, extra_id, "COINS!", 0, 1, 0, random.randint(5, 100), 1)
            elif choosed==3: # Mega box
                addof(data, extra_id, "MEGA BOX!", 0, 10, 0, 1, 0)
            elif choosed==4: # Normal box
                addof(data, extra_id, "BIG BOX", 0, 14, 0, 1, 1)
            elif choosed==5: # small box
                addof(data, extra_id, "BRAWL BOX", 0, 6, 0, 1, 1)
            elif choosed==6: # Power points
                addof(data, extra_id, "POWER POINTS", 0, 8, random.randint(0, 39), random.randint(0, 300), 1)
            elif choosed==7: # Coins
                addof(data, extra_id, "COINS!", 0, 1, 0, random.randint(5, 100), 1)
            elif choosed==8: # Mega box
                addof(data, extra_id, "MEGA BOX!", 0, 10, 0, 1, 0)
            elif choosed==9: # Normal box
                addof(data, extra_id, "BIG BOX", 0, 14, 0, 1, 1)
            elif choosed==10: # small box
                addof(data, extra_id, "BRAWL BOX", 0, 6, 0, 1, 1)
            
        #CHEAP (LOWER THAN 50)        
        else:
            extra_id = str(len(data))
            choosed=random.randint(1,13)
            if choosed==1: # Power points
                addof(data, extra_id, "Power Points", random.choice([25, 50]), 8, random.randint(0, 39), random.randint(0, 300), 1)
            elif choosed==2: # Coins
                addof(data, extra_id, "COINS", random.choice([25, 50]), 1, 0, random.randint(0, 500), 1)
            elif choosed==3: # Mega box
                addof(data, extra_id, "MEGA BOX!", random.choice([25, 50]), 10, 0, 1, 0)
            elif choosed==4: # Normal box
                addof(data, extra_id, "BIG BOX", random.choice([25, 50]), 14, 0, 1, 1)
            elif choosed==5: # small box
                addof(data, extra_id, "BRAWL BOX", random.choice([25, 50]), 6, 0, 1, 1)
            elif choosed==6: # small box
                addof(data, extra_id, "PIN PACK", random.choice([0, 25]), 21, 0, 1, 0)
            elif choosed==7: #porn
                addof(data, extra_id, "BRAWLER", random.choice([50, 10]), 3, random.randint(0, 39), 1, 0)
            elif choosed==8: #porn
                addof(data, extra_id, "GEMS", 0, 16, 0, random.choice([5, 15]), 1)
            elif choosed==9: # small box
                addof(data, extra_id, "PIN PACK", random.choice([5, 25]), 21, 0, 1, 0)
            elif choosed==10: #porn
                addof(data, extra_id, "BRAWLER", random.choice([50, 10]), 3, random.randint(0, 39), 1, 0)
            elif choosed==11: #porn
                addof(data, extra_id, "GEMS", 0, 16, 0, random.choice([5, 15]), 1)
            elif choosed==12: #porn
                addof(data, extra_id, "BRAWLER", random.choice([50, 10]), 3, random.randint(0, 39), 1, 0)
            elif choosed==13: #porn
                addof(data, extra_id, "GEMS", 0, 16, 0, random.choice([5, 15]), 1)
    os.makedirs('JSON', exist_ok=True)
    with open('JSON/offers.json', 'w') as f:
        json.dump(data, f, indent=4)
    log("offers updated successfully!")

refreshoffers()
nexttime = time.time() + timer

while True:
    currtime = time.time()
    if currtime >= nexttime:
        refreshoffers()
        nexttime = currtime + timer
    try:
        with open('JSON/offers.json', 'r') as f:
            data = json.load(f)
        for offr in data.values():
            if 'Timer' in offr and isinstance(offr['Timer'], int) and offr['Timer'] > 0:
                offr['Timer'] -= 1
        with open('JSON/offers.json', 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        logerr(f"error occurred: {e}")
    time.sleep(1)