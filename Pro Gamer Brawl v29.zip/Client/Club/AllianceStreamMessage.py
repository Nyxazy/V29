from datetime import datetime
from Utils.Writer import Writer
from Server.Club.AllianceChatServer import AllianceChatServer
from Server.Club.AllianceBotChatServerMessage import AllianceBotChatServerMessage
from database.DataBase import DataBase
from Utils.Reader import BSMessageReader
from Server.Login.LoginFailedMessage import LoginFailedMessage
from Logic.Transfer import Transfer
from Logic.AddNotification import AddNotification
import re
import json
import os
import sqlite3
from Logic.LogicDeviceLinkDoneMessage import LogicDeviceLinkDoneMessage

class AllianceStreamMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False

    def decode(self):
        now = datetime.now()
        self.msg = self.read_string()
        args = self.msg.split()
       
        #give
        if self.msg.lower().startswith("/pay") and len(args) == 4:
            try:
                target_low_id = int(args[1])
                currency = args[2].lower()
                amount = int(args[3])

                if amount <= 0:
                    self.bot_msg = "Amount must be a positive number!"
                    self.IsAcmd = True
                    return

                conn = sqlite3.connect("database/Player/plr.db")
                cursor = conn.cursor()

                cursor.execute("SELECT * FROM plrs WHERE lowID = ?", (target_low_id,))
                target_data = cursor.fetchone()

                if not target_data:
                    self.bot_msg = "Player with that ID was not found!"
                    self.IsAcmd = True
                    conn.close()
                    return

                if currency not in ["gems", "gold"]:
                    self.bot_msg = "Invalid currency! Use 'gems' or 'gold'."
                    self.IsAcmd = True
                    conn.close()
                    return

                cursor.execute(f"SELECT {currency} FROM plrs WHERE lowID = ?", (self.player.low_id,))
                result = cursor.fetchone()
                if not result:
                    self.bot_msg = "Could not fetch your account data!"
                    self.IsAcmd = True
                    conn.close()
                    return

                sender_balance = result[0]

                if sender_balance < amount:
                    self.bot_msg = f"You do not have enough {currency} to give!"
                    self.IsAcmd = True
                    conn.close()
                    return

                cursor.execute(
                    f"UPDATE plrs SET {currency} = {currency} - ? WHERE lowID = ?",
                    (amount, self.player.low_id),
                )
                cursor.execute(
                    f"UPDATE plrs SET {currency} = {currency} + ? WHERE lowID = ?",
                    (amount, target_low_id),
                )
                conn.commit()
                conn.close()

                self.bot_msg = f"Successfully payed {amount} {currency} to player with ID {target_low_id}."
                self.IsAcmd = True

            except ValueError:
                self.bot_msg = "Invalid format! Use /pay <playerLowID> <gems|gold> <amount>"
                self.IsAcmd = True
        #CONNECT
        elif self.msg.lower().startswith("/register")  and len(args) == 3:
            self.IsAcmd = True
            accname = args[1]
            accpass = args[2]
            result = Transfer.register([accname, accpass, self.player.low_id])
            if result == False:
                self.bot_msg = "There is a account that already uses these credentials or you are already registered!"
                self.IsAcmd = True
                return
            else:
                self.bot_msg = "You are successfully registered! Thank you for registering!"
                self.IsAcmd = True
                return
            self.IsAcmd = True

        else:
            self.IsAcmd = False
            
        if self.msg.lower().startswith("/login") and len(args) == 3:
            self.IsAcmd = True
            accname = args[1]
            accpass = args[2]
            result = Transfer.login([accname, accpass, self.player.low_id])
            if result == False:
                self.bot_msg = "Wrong credentials or you are trying to login to your current account!"
                self.IsAcmd = True
                return
            else:
                plrtoken = DataBase.gettoken(result[1])
                if plrtoken != "token not found!!":
                    LogicDeviceLinkDoneMessage(self.client, self.player, DataBase.gettoken(result[1]), result[1]).send()
                    self.player.err_code = 8
                    LoginFailedMessage(self.client, self.player, "Successfully logged in!").send()
                    return
                else:
                    self.IsAcmd = True
                    self.bot_msg = "Token not found!"
                    return
                
        else:
            self.IsAcmd = False
        
        if self.msg.lower().startswith("/changepass") and len(args) == 4:
            self.IsAcmd = True
            accname = args[1]
            accpass = args[2]
            accnewpass = args[3]
            result = Transfer.changepass([accname, accpass, accnewpass])
            if result == False:
                self.bot_msg = "Wrong credentials!"
                self.IsAcmd = True
                return
            else:
                self.bot_msg = f"Successfully changed password for {accname}!"
                self.IsAcmd = True
                return
        else:
            self.IsAcmd = False
        #clubmailFunnybunny
        if self.msg.lower().startswith("/clubmail") and len(args) >= 2:
            self.IsAcmd = True

            matc = re.match(r'^"([^"]+)"$', args[1])
            text = ""

            if matc:
                text = matc.group(1)

            if self.player.club_role == 2 or self.player.club_role == 4:
                DataBase.loadClub(self, self.player.club_low_id)

                for i in self.plrids:
                    AddNotification.ById([i, 82, f"From club: {self.clubName}\n{text}",
                                          [self.player.name, self.player.name_color]])

                self.bot_msg = "Sent club mail successfully!"
                return

            else:
                self.IsAcmd = False
        #help
        if self.msg.lower().startswith('/help'):
            self.bot_msg = (
                'Available commands:\n\n'
                '/help - shows all available commands\n'
                '/status - shows server and player stats\n'
                '/pay - pay someone\n'
                '/redeem - redeem a code\n'
                '/clubmail - send clubmail\n\n'
                'VIP commands:\n'
                '/theme - change your client theme\n\n'
                'Pro Gamer Brawl ID\n'
                '/register [nickname] [password] - register an account\n'
                '/login [nickname] [password] - login to your account\n'
                '/changepass [name] [oldpass] [newpass] - change a password\n\n'
                'How to use:\n'
                '/pay [id] [gold|gems] [amount]\n'
                '/redeem [code]\n'
                '/theme [theme id]\n'
                '/clubmail "text"'
            )
            self.IsAcmd = True
                
        elif self.msg.lower() == '/theme':
            if self.player.vip == 1:
                self.bot_msg = f'Choose a background ID in the menu!\n0 - default\n1 - LNY\n2 - CR\n3 - Easter\n4 - GoldenWeek\n5 - Retropolis\n6 - Mecha\n7 - Halloween\n8 - Brawlidays\n9 - LNY20\n10 - PSG\n11 - SC10\n12 - Bazaar\n13 - Monsters\n14 - MoonFestival20\n15 - Punk2021\n16 - Enchanted Woods\n17 - Enchanted Forest\n18 - Brawlentines\n19 - CN Moon Festival\n20 - CN Virgo Collete\n21 - CN Cancer Edgar\n22 - Moon Brawl Dark Woods\n23 - Winterbrawl MoonBrawl\n24 - SpikBrawl collab v1\n25 - SpikBrawl v2\n26 - GhostTrain\n27 - CandyLand\n28 - BizzareCircus\n29 - BrawlyToons\n30 - LoveSwamp\n31 - Madevil\n32 - CandyLand v2\n33 - Unknown\n34 -  World Finals 2023\n35 - Brawlidays 2023'
            else:
                self.bot_msg = f'You dont have VIP\nto get it you should buy from our e-shop or win a giveaway'
                self.IsAcmd = True
                
        elif self.msg.lower().startswith('/theme'):
            if self.player.vip == 1:
                try:
                    newStarpoints = self.msg.split(" ", 6)[1:]
                    DataBase.replaceValue(self, 'theme', int(newStarpoints[0]))
                    self.bot_msg = f'Re-enter the game, the background has been successfully changed'
                    self.IsAcmd = True
                except:
                    pass
            else:
                self.bot_msg = f'You dont have VIP\nto get it you should buy from our e-shop or win a giveaway'
                self.IsAcmd = True        
                
        elif self.msg.lower() == '/status':
            self.bot_msg = f'Server Status:\nVersion: 29.270\nServer Version: 1.0\n\nPlayer Status:\nTime: {now.strftime("%H:%M %d.%m.%Y")}\nRegion: {self.player.Region}\nAccount Creation Date: {self.player.creation_date}\nID: {self.player.low_id}\nCurrent Winstreak: {self.player.winstreak}\nHighest Winstreak: {self.player.highestwinstreak}\n\nVIP Status: {self.player.vip}'
            self.IsAcmd = True                               
        #redeem
        elif self.msg.lower().startswith("/redeem") and len(args) == 2:
            code = args[1].strip()
            vip_file = "vip_codes.json"
            config_file = "config.json"

            vips = []
            if os.path.exists(config_file):
                with open(config_file, "r", encoding="utf-8") as cfg:
                    try:
                        vips = json.load(cfg).get("vips", [])
                    except json.JSONDecodeError:
                        vips = []

            if self.player.low_id in vips:
                self.bot_msg = "You already got VIP!"
                self.IsAcmd = True
                return

            if not os.path.exists(vip_file):
                self.bot_msg = "VIP system is not available right now."
                self.IsAcmd = True
                return

            with open(vip_file, "r+", encoding="utf-8") as f:
                try:
                    vip_codes = json.load(f)
                except json.JSONDecodeError:
                    vip_codes = []

                found = None
                for item in vip_codes:
                    if (isinstance(item, str) and item == code) or (
                        isinstance(item, list) and len(item) > 0 and item[0] == code
                    ):
                        found = item
                        break

                if found:
                    self.bot_msg = "Code is correct! VIP is successfully rewarded to your account."
                    vip_codes.remove(found)
                    f.seek(0)
                    json.dump(vip_codes, f, indent=4)
                    f.truncate()

                    if os.path.exists(config_file):
                        with open(config_file, "r+", encoding="utf-8") as cfg:
                            try:
                                config = json.load(cfg)
                            except json.JSONDecodeError:
                                config = {}
                            vips = config.get("vips", [])
                            if self.player.low_id not in vips:
                                vips.append(self.player.low_id)
                                config["vips"] = vips
                                cfg.seek(0)
                                json.dump(config, cfg, indent=4)
                                cfg.truncate()
                    else:
                        with open(config_file, "w", encoding="utf-8") as cfg:
                            json.dump({"vips": [self.player.low_id]}, cfg, indent=4)
                else:
                    self.bot_msg = "Invalid code! Did u read it right? Try again."

            self.IsAcmd = True

        else:
            self.IsAcmd = False
        #debug menu    
        if self.msg.lower() == '/debug':
            if self.player.vip == 1:
                self.bot_msg = 'SECRET MENU\n/debug_gems - gives gems\n/debug_gold - gives gold\n/debug_starpoints - gives starpoints\n/debug_max - give everything at once'
            else:
                self.bot_msg = f'You dont have VIP\nto get it you should buy from our e-shop or win a giveaway'
                self.IsAcmd = True     

        elif self.msg.lower() == '/debug_max':
            self.send_ofs = True
            DataBase.replaceValue(self, 'gold', 99999)
            DataBase.replaceValue(self, 'gems', 99999)
            DataBase.replaceValue(self, 'starpoints', 99999)
            self.IsAcmd = True

        elif self.msg.lower().startswith('/debug_gems'):
            try:
                newGems = self.msg.split(" ", 4)[1:]
                DataBase.replaceValue(self, 'gems', int(newGems[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass

        elif self.msg.lower().startswith('/debug_gold'):
            try:
                newGold = self.msg.split(" ", 4)[1:]
                DataBase.replaceValue(self, 'gold', int(newGold[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass

        elif self.msg.lower().startswith('/debug_starpoints'):
            try:
                newStarpoints = self.msg.split(" ", 10)[1:]
                DataBase.replaceValue(self, 'starpoints', int(newStarpoints[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass
                
    def process(self):
        if not self.send_ofs and not self.IsAcmd:
            DataBase.Addmsg(
                self,
                self.player.club_low_id,
                2,
                0,
                self.player.low_id,
                self.player.name,
                self.player.club_role,
                self.msg,
            )
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServer(self.client, self.player, self.msg, self.player.club_low_id).send()

        if self.bot_msg != '':
            AllianceChatServer(self.client, self.player, self.msg, self.player.club_low_id, True).send()
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()