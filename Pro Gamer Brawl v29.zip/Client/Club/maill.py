from Server.Club.Mail import AllianceMailWindow
from Logic.AddNotification import AddNotification
from Utils.Reader import BSMessageReader
from database.DataBase import DataBase

class SendClubMail(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
    	self.read_int()
    	self.msg = self.read_string()

    def process(self):
        if not self.msg:
            AllianceMailWindow(self.client, self.player, 114).send()
        elif self.msg and self.player.club_role > 0:
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AddNotification.ById([i, 82, f"<cec0000>F<cd90000>R<cc70000>O<cb40000>M<ca10000> <c8f0000>C<c8f0000>L<ca10000>U<cb40000>B<cc70000>:<cd90000> </c> {self.clubName}\n{self.msg}", [self.player.name, self.player.name_color]])
            AllianceMailWindow(self.client, self.player, 113).send()