'''
content creator code reward logic by batu

rewards:
gems
golds
skin
brawler
pin

i added a system if the skin / brawler pin is already on data it will give 100 golds but that doesnt works so announce it on your channel as:
if you already got the skin / brawler / pin reward it will do nothing to your data
'''
from Utils.Reader import BSMessageReader
from database.DataBase import DataBase
from Server.Home.SetSupportedCreatorReponse import SetSupportedCreatorReponse
from Logic.Commands.Server.AvailableServerCommandMessage import AvailableServerCommandMessage
from Server.Login.LoginFailedMessage import LoginFailedMessage
from Logic.Commands.Server import LogicBrawlerDataCommand
from Logic.Commands.Server.LogicTropRoad import LogicTropRoad
from Logic.Commands.Client.LogicBoxDataCommand import LogicBoxDataCommand
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply
from Logic.LogicBP import LogicBP
from Logic.LogicBuy import LogicBuy
from Logic.Pin import Pin
from Logic.PinPack import PinPack
import json
import sqlite3

class SetSupportedCreatorMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        self.player.ccc = self.read_string()

    def process(self):
        config = open('config.json', 'r')
        content = config.read()
        settings = json.loads(content)

        config2 = open('ccc_codes.json', 'r')
        content2 = config2.read()
        settings2 = json.loads(content2)
        if self.player.ccc == '':
            DataBase.replaceValue(self, 'SCC', self.player.ccc)
            AvailableServerCommandMessage(self.client, self.player, 215).send()
        elif self.player.ccc in settings['CCC']:
            DataBase.replaceValue(self, 'SCC', self.player.ccc)
            AvailableServerCommandMessage(self.client, self.player, 215).send()

        elif self.player.ccc in settings2['codes']:
            # REWARD LOGIC START

            if self.player.low_id in settings2['codes'][self.player.ccc]['whogot']:
                self.player.err_code = 8
                LoginFailedMessage(self.client, self.player, f"You already redeemed the code: {self.player.ccc}!").send()
                return
            else:
                if settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "gem":
                    rmult = int(settings2['codes'][self.player.ccc]['SETTINGS']['Multiplier'])
                    LogicBuy(self.client, self.player, 2, 0, 0, rmult, 0, 0, 0, 0, 0, 0, 0, 0).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "gold":
                    rmult = int(settings2['codes'][self.player.ccc]['SETTINGS']['Multiplier'])
                    LogicTropRoad(self.client, self.player, 100, rmult).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "skin":
                    rmult = int(settings2['codes'][self.player.ccc]['SETTINGS']['Multiplier'])
                    LogicBuy(self.client, self.player, 7, 0, 0, 0, 0, 0, 0, 0, 0, rmult, 0, 0).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "brawler":
                    rmult = int(settings2['codes'][self.player.ccc]['SETTINGS']['Multiplier'])
                    LogicBuy(self.client, self.player, 6, 0, 0, 1, 0, 0, rmult, 0, 0, 0, 0, 0).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "pin":
                    rmult = int(settings2['codes'][self.player.ccc]['SETTINGS']['Multiplier'])
                    Pin(self.client, self.player, rmult).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "pinpack":
                    PinPack(self.client, self.player).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "smallbox":
                    Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 10}).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "megabox":
                    Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 11}).send()
                elif settings2['codes'][self.player.ccc]['SETTINGS']['Reward'] == "normalbox":
                    Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 12}).send()

                #save to file
                settings2['codes'][self.player.ccc]['whogot'].append(self.player.low_id)
                with open('ccc_codes.json', "w") as f:
                    json.dump(settings2, f, indent=4)

            # REWARD LOGIC END
        
        else:
            SetSupportedCreatorReponse(self.client, self.player).send()