import os
import json
import hashlib
import time
import threading

ASSETS_DIR = "assets"
OUTPUT_FILE = "fingerprint.json"

# CHANGE THIS — your custom version number
VERSION = "29.270 (v1.0)"

# Shared variables for progress
progress_count = 0
total_files = 0
lock = threading.Lock()


def print_banner():
    banner = r"""
 ____                     _    _____ _                 
|  _ \                   | |  / ____| |                
| |_) |_ __ __ ___      _| | | (___ | |_ __ _ _ __ ___ 
|  _ <| '__/ _` \ \ /\ / / |  \___ \| __/ _` | '__/ __|
| |_) | | | (_| |\ V  V /| |  ____) | || (_| | |  \__ \
|____/|_|  \__,_| \_/\_/ |_| |_____/ \__\__,_|_|  |___/
                                                        
"""
    print(banner)


def sha1_of_file(path):
    sha1 = hashlib.sha1()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            sha1.update(chunk)
    return sha1.hexdigest()


def print_progress_bar(iteration, total, prefix='', suffix='', length=50):
    percent = 100 * (iteration / float(total))
    filled_length = int(length * iteration // total)
    bar = '█' * filled_length + '-' * (length - filled_length)
    print(f'\r{prefix} |{bar}| {percent:6.2f}% {suffix}', end='\r')
    if iteration >= total:
        print()


def animate_progress():
    """Continuously update progress bar every 1.5 seconds"""
    while True:
        with lock:
            current = progress_count
        print_progress_bar(current, total_files, prefix="Progress", suffix="Complete")
        if current >= total_files:
            break
        time.sleep(1.5)


def generate_fingerprint():
    global progress_count, total_files

    entries = []

    # COLLECT ALL FILES
    all_files = []
    for root, dirs, files in os.walk(ASSETS_DIR):
        for file in files:
            full_path = os.path.join(root, file)
            all_files.append(full_path)

    total_files = len(all_files)
    print(f"Hashing {total_files} files...")

    # Start progress animation in a separate thread
    thread = threading.Thread(target=animate_progress)
    thread.start()

    # HASH ALL FILES
    for full_path in all_files:
        rel_path = os.path.relpath(full_path, ASSETS_DIR).replace("\\", "/")
        sha = sha1_of_file(full_path)
        rel_path_escaped = rel_path.replace("/", "\\/")

        entries.append({
            "file": rel_path_escaped,
            "sha": sha
        })

        with lock:
            progress_count += 1

    # Wait for progress thread to finish
    thread.join()

    # SORT FILES
    entries.sort(key=lambda x: x["file"])

    # BUILD JSON ARRAY
    files_compact = ",".join(
        [f'{{"file":"{e["file"]}","sha":"{e["sha"]}"}}' for e in entries]
    )

    # TEMP JSON WITHOUT SHA
    temp_json = f'{{"files":[{files_compact}],"version":"{VERSION}"}}'

    # FINAL SHA
    final_sha = hashlib.sha1(temp_json.encode("utf-8")).hexdigest()

    # FINAL JSON WITH SHA
    final_json = f'{{"files":[{files_compact}],"sha":"{final_sha}","version":"{VERSION}"}}'

    with open(OUTPUT_FILE, "w") as f:
        f.write(final_json)

    print("Generated:", OUTPUT_FILE)
    print("Fingerprint SHA:", final_sha)


if __name__ == "__main__":
    print_banner()
    generate_fingerprint()
