import sqlite3
import json
import random
import time

class AddNotification:
    @classmethod
    def EveryPlr(cls, data):
        conn = sqlite3.connect("database/Player/plr.db")
        cur = conn.cursor()
        typ = data[0]
        text = data[1]
        multip = data[2]
        
        cur.execute("SELECT lowID, notifs FROM plrs")
        everyone = cur.fetchall()
        
        for low_id, notifs in everyone:
            notifss = json.loads(notifs)
            newnotif = {
                "ID": typ,
                "index": random.randint(1, 999999999),
                "seen": False,
                "ago": int(time.time()),
                "msg": text,
                "msg_TYPE": 1,
            }
            if typ == 89:
                newnotif["gems"] = multip
            elif typ == 94:
                newnotif["skin_id"] = multip
            elif typ == 82:
                newnotif["plr_name"] = multip[0]
                newnotif["plr_color"] = multip[1]
                newnotif["msg_TYPE"] = -1
            notifss.append(newnotif)
            cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?", (json.dumps(notifss), low_id))
        conn.commit()
        conn.close()
        
    @classmethod
    def ById(cls, data):
        conn = sqlite3.connect("database/Player/plr.db")
        cur = conn.cursor()
        plrid = data[0]
        typ = data[1]
        text = data[2]
        multip = data[3]
        
        cur.execute("SELECT notifs FROM plrs WHERE lowID = ?", (plrid,))
        result = cur.fetchone()
        
        notifss = json.loads(result[0])
        newnotif = {
            "ID": typ,
            "index": random.randint(1, 999999999),
            "seen": False,
            "ago": int(time.time()),
            "msg": text,
            "msg_TYPE": 1,
        }
        if typ == 89:
            newnotif["gems"] = multip
        elif typ == 94:
            newnotif["skin_id"] = multip
        elif typ == 82:
            newnotif["plr_name"] = multip[0]
            newnotif["plr_color"] = multip[1]
        notifss.append(newnotif)
        cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?", (json.dumps(notifss), plrid))
        conn.commit()
        conn.close()