from database.DataBase import DataBase
from Utils.Reader import BSMessageReader
import json
class LogicPurchaseHeroLvlUpMaterialCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.gold = self.read_Vint()

    def process(self):
        coinpack=json.load(open("coin_packs.json"))
        
        if str(self.gold) in coinpack:
            pack = coinpack[str(self.gold)]
            cost = pack["cost"]
            amount = pack["amount"]
            
            if self.player.gems >= cost:
                n1 = self.player.gold + amount
                n2 = self.player.gems - cost
                self.player.gold = n1
                self.player.gems = n2
                DataBase.replaceValue(self, 'gold', self.player.gold)
                DataBase.replaceValue(self, 'gems', self.player.gems)

            else:
                print("dbg: not enough gems")
        else:
            print("dbg: coin pack not found")

