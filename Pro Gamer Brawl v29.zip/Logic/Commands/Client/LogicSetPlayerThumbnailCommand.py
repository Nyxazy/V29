from database.DataBase import DataBase
from Utils.Reader import BSMessageReader
from Server.OutOfSyncMessage import OutOfSyncMessage

class LogicSetPlayerThumbnailCommand(BSMessageReader):
    def init(self, client, player, initial_bytes):
        super().init(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.player.profile_icon = self.read_Vint()                

    def process(self):
        locked = [67, 64]
        if self.player.profile_icon == 67:
            if self.player.UnlockedBrawlers["33"] == 0:
                self.player.err_code = 1
                OutOfSyncMessage(self.client, self.player, f"You don't have this profile picture").send()
            else:
                DataBase.replaceValue(self, 'profile_icon', self.player.profile_icon)
        else:
            if self.player.profile_icon not in locked:
                DataBase.replaceValue(self, 'profile_icon', self.player.profile_icon)
                                
        if self.player.profile_icon == 64:
            if self.player.UnlockedSkins["52"] == 0:
                self.player.err_code = 1
                OutOfSyncMessage(self.client, self.player, f"You don't have this profile picture").send()
            else:
                DataBase.replaceValue(self, 'profile_icon', self.player.profile_icon)
        else:
            if self.player.profile_icon not in locked:
                DataBase.replaceValue(self, 'profile_icon', self.player.profile_icon)
        