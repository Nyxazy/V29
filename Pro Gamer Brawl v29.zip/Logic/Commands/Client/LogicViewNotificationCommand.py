import json
from Utils.Reader import BSMessageReader
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd
from database.DataBase import DataBase
from Logic.LogicBuy import LogicBuy
import sqlite3

class LogicViewNotificationCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes, id, k, bp, id2=0):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.a = self.read_Vint()
        self.b = self.read_Vint()
        self.c = self.read_Vint()
        self.d = self.read_Vint()
        self.notif = self.read_Vint()

    def process(self):
        plrnotif = self.player.notifs
        for notif in plrnotif:
            
            if notif["ID"] == 81:
                notif['seen'] = True
                conn = sqlite3.connect("database/Player/plr.db")
                cur = conn.cursor()
                cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?",(json.dumps(plrnotif), self.player.low_id))
                conn.commit()
                conn.close()
            
            if self.notif == notif['index']:
                if notif["ID"] == 89:
                    MilestonesClaimSupplyByLkPrtctrd(self.client, self.player, "BPLkPrtctrd", {"Character": [0, 0], "Skin": [0, 0],"Type":8,"Amount": notif["gems"], "Road": 0, "Season": 0, "Level": -2}).send()
                    notif['seen'] = True
                    conn = sqlite3.connect("database/Player/plr.db")
                    cur = conn.cursor()
                    cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?",(json.dumps(plrnotif), self.player.low_id))
                    conn.commit()
                    conn.close()
                if notif["ID"] == 94:
                    LogicBuy(self.client, self.player, 7, 0, 0, 0, 0, 0, 0, 0, 0, notif["skin_id"], 0, 0).send()
                    notif['seen'] = True
                    conn = sqlite3.connect("database/Player/plr.db")
                    cur = conn.cursor()
                    cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?",(json.dumps(plrnotif), self.player.low_id))
                    conn.commit()
                    conn.close()