from Utils.Writer import Writer

class LogicDeviceLinkDoneMessage(Writer):

    def __init__(self, client, player, tken, aID):
        super().__init__(client)
        self.id = 26007
        self.player = player
        self.tooken = tken
        self.aaID = aID

    def encode(self):
        self.writeString(self.tooken)
        self.wLong(self.aaID)