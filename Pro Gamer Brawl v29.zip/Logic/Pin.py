from Utils.Writer import Writer
import random 
from database.DataBase import DataBase

class Pin(Writer):

    def __init__(self, client, player, pin):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.pin = pin
        # Define pin rarities
        self.common = [self.pin, self.pin, self.pin]
        self.rare = [self.pin, self.pin, self.pin]
        self.epic = [self.pin, self.pin, self.pin]

    def get_random_pin(self, rarity_list):
        # Filter out already unlocked pins
        available_pins = [pin for pin in rarity_list if str(pin) not in self.player.UnlockedPins or self.player.UnlockedPins[str(pin)] != 1]
        
        if not available_pins:
            # If all pins are unlocked, just pick a random one from the rarity
            return random.choice(rarity_list)
        return random.choice(available_pins)

    def encode(self):
        # Get 2 common pins and 1 rare/epic pin
        pin_rewards = [
            self.get_random_pin(self.common)
        ]
        
        # Write header
        self.writeVint(203)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(100)  # Box ID
        
        # Write rewards count
        self.writeVint(len(pin_rewards))  # Number of items (3 pins)
        
        # Write each pin reward
        for pin_id in pin_rewards:
            self.writeVint(1)  # Reward amount
            self.writeVint(0)  # CsvID 16
            self.writeVint(11)  # Reward ID (pin)
            self.writeVint(0)  # CsvID 29
            self.writeScId(52, pin_id)  # Pin ID
            self.writeVint(0)  # CsvID 23
            self.writeVint(0)
            self.writeVint(0)
            
            # Update player's unlocked pins
            self.player.UnlockedPins[str(pin_id)] = 1

        
        # Save to database
        DataBase.replaceValue(self, 'UnlockedPins', self.player.UnlockedPins)
        
        
        for _ in range(13):
            self.writeVint(0)