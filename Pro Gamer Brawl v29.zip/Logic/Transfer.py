# by @emiremredersiniz

import sqlite3
import json
from Logic.AddNotification import AddNotification
from database.DataBase import DataBase
class Transfer:
    
    @staticmethod
    def register(creds):
        accname = creds[0]
        accpass = creds[1]
        acclowid = creds[2]
        
        credsj = json.load(open("creds.json"))
        
        for cred in credsj: # really cool security
            if cred["accname"] == accname and cred["accpass"] == accpass or cred["acclowid"] == acclowid:
                return False
                
        newcred = {
            "accname": accname,
            "accpass": accpass,
            "acclowid": acclowid
        }
        credsj.append(newcred)
        json.dump(credsj, open("creds.json", "w"), indent=4)
        AddNotification.ById([acclowid, 94, "Registered in Pro Game Brawl ID", 59])
                
    @staticmethod
    def login(creds):
        accname = creds[0]
        accpass = creds[1]
        targetlowid = creds[2]
        
        credsj = json.load(open("creds.json"))
        
        for cred in credsj:
            if cred["accname"] == accname and cred["accpass"] == accpass and cred["acclowid"] != targetlowid:
                AddNotification.ById([cred["acclowid"], 81, "Somebody logged into your account.", 0])
                return [True, cred["acclowid"]]
            else:
                return False
    
    @staticmethod
    def changepass(creds):
        accname = creds[0]
        accoldpass = creds[1]
        accnewpass = creds[2]
        
        credsj = json.load(open("creds.json"))
        for cred in credsj:
            if cred["accname"] == accname and cred["accpass"] == accoldpass:
                cred["accpass"] = accnewpass
                json.dump(credsj, open("creds.json", "w"), indent=4)
                return
        return False
                
            