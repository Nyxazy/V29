from Utils.Writer import Writer
from Utils.Battle import Battle
from Logic.PlayerSession import PlayerSession
from Server.Battle.UDPConnectionInfo import UDPConnectionInfo

class MatchmakingInfoMessage(Writer):

    def init(self, client, player):
        super().init(client)
        self.id = 20405
        self.player = player

    def encode(self):
        for room in Battle.onlineBattle:
            if room['index'] == self.player.index:
                self.writeInt(30)  # Timer / doesn't work in v12
                self.writeInt(room['plr_count'])  # Players found
                self.writeInt(2)  # max players but you can change
                self.writeInt(0)
                self.writeInt(0)
                self.writeBoolean(False)

                if room['plr_count'] == 2:
                    plrs = room['plrs']
                    self.player.inmm = False
                    UDPConnectionInfo(self.client, self.player).send()
                    battle = PlayerSession(self.client, self.player, plrs)
                    battle.start()