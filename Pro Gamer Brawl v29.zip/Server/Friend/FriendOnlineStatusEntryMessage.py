from Utils.Writer import Writer

class FriendOnlineStatusEntryMessage(Writer):

    def __init__(self, client, player, lowID, status, room_id):
        super().__init__(client)
        self.id = 24555
        self.player = player 
        self.lowID = lowID
        self.status = status
        self.room_id = room_id
    def encode(self):
        self.writeInt(0)
        self.writeInt(self.lowID)#low id
        self.writeBoolean(True)
        self.writeInt(0)
        self.writeInt(self.lowID)#lоw id
        self.writeVint(self.status)#status
        self.writeVint(0)#If there's 0 at the top, then put 1 here and it won't be in the network
        if self.room_id > 0:
            self.writeBoolean(True)
        else:
            self.writeBoolean(False)
        self.writeBoolean(False)