from Utils.Writer import Writer
from database.DataBase import DataBase
from Logic.Shop import Shop
import json
import time
from datetime import datetime
from Logic.EventSlots import EventSlots
from Server.Login.LoginFailedMessage import LoginFailedMessage
from Server.Home.BattleBan import BattleBan
from Logic.MCbyLkPrtctrd.MilestonesClaimHelpByLkPrtctrd import MilestonesClaimHelpByLkPrtctrd as LkPrtctrd
from Utils.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Logic.Quest import Quest
from Logic.QuestMission import Quests
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
class OwnHomeDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player
        self.timestamp = int(datetime.timestamp(datetime.now()))

    def encode(self):
        DataBase.loadAccount(self)

        self.writeVint(0)
        self.writeVint(self.timestamp)  # Timestamp

        self.writeVint(self.player.trophies)  # Player Trophies
        self.writeVint(self.player.trophies)  # Player Max Reached Trophies
        self.writeVint(self.player.highest_trophies)
        self.writeVint(self.player.Troproad)
        self.writeVint(220+self.player.player_experience)  # Player exp
        #DataBase.replaceValue(self, "Troproad", 1)
        self.writeScId(28, self.player.profile_icon)  # Player Icon ID
        self.writeScId(43, self.player.name_color)  # Player Name Color ID

        self.writeVint(0)  # array

        # Selected Skins array
        self.writeVint(1)
        self.writeVint(29)
        self.writeVint(self.player.skin_id)  # skinID

        # Unlocked Skins array
#        self.writeVint(365)
#        for i in range(365):
#            self.writeScId(29, int(i))
        new_season_time = (2025, 2, 14, 22, 0, 0, 0, 0, 0)  # The last three zeros are for: day of week, day of year, and DST flag

# Epoch reference time (2024-02-12 18:23:00 UTC)
        the_time = time.gmtime()

# Convert struct_time to seconds since epoch
        new_season_seconds = int(time.mktime(new_season_time))
        the_seconds = int(time.mktime(the_time))

# Calculate the difference
        time_season_difference = new_season_seconds - the_seconds

        self.writeVint(len(self.player.UnlockedSkins))
        for i in self.player.UnlockedSkins:
            if self.player.UnlockedSkins[str(i)]==1:
                self.writeScId(29, int(i))
            else:
                self.writeScId(29, 0)

        self.writeVint(0)  # array

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeBoolean(True)  # "token limit reached message" if true

        self.writeVint(0)  # Token doubler ammount
        self.writeVint(0)  # Season End Timer
        self.writeVint(time_season_difference)
        self.writeVint(time_season_difference)

        self.writeVint(0)
        self.writeBoolean(False)
        self.writeBoolean(False)

        self.writeByte(4)  # related to shop token doubler

        for x in range(3):
            self.writeVint(2)

        self.writeVint(0)
        self.writeVint(0)

        # Shop Array
        Shop.EncodeShopOffers(self)

        with open('config.json', 'r', encoding='utf-8') as f:
            settings = json.load(f)
        # Shop Array End

        self.writeVint(0)  # array

        self.writeVint(200)
        self.writeVint(0)  # Time till Bonus Tokens (seconds)

        self.writeVint(0)  # array

        self.writeVint(self.player.tickets)  # Tickets
        self.writeVint(1)

        self.writeScId(16, self.player.brawler_id)  # Selected Brawler

        self.writeString(self.player.Region)  # Location
        self.writeString(f"{self.player.ccc}")  # Supported Content Creator

		# Animation ID
        self.writeVint(2) #a dudka
        self.writeInt(4)
        self.writeLkPrtctrdInt(self.player.bet)
        self.writeInt(3)
        self.writeLkPrtctrdInt(self.player.betTok)

        self.writeVint(0)  # array
        
        LkPrtctrd.BrawlPassEncode(self,self.client,self.player)

        self.writeVint(0)  # array

        Quests.EncodeQuestsMissions(self)#quest logic
        
        self.writeBoolean(True) # Emojis Boolean
        self.writeVint(len(self.player.emotes_id))
        for emotes_id in self.player.emotes_id:
            if self.player.UnlockedPins[str(emotes_id)]==1:
            	self.writeScId(52, emotes_id)
            	self.writeVint(1)
            	self.writeVint(1)
            	self.writeVint(1)
            else:
            	self.writeScId(52, 0)
            	self.writeVint(1)
            	self.writeVint(1)
            	self.writeVint(1)

        self.writeVint(2019049)

        self.writeVint(100)
        self.writeVint(10)

        self.writeVint(30)
        self.writeVint(3)
        self.writeVint(80)
        self.writeVint(10)

        self.writeVint(50)
        self.writeVint(1000)

        self.writeVint(500)
        self.writeVint(50)
        self.writeVint(999900)

        self.writeVint(0)  # array

        self.writeVint(8)  # array

        self.writeVint(1)
        self.writeVint(2)
        self.writeVint(3)
        self.writeVint(4)
        self.writeVint(5)
        self.writeVint(6)
        self.writeVint(7)
        self.writeVint(8)

        # Logic Events
        count = len(EventSlots.maps)
        self.writeVint(count)

        for map in EventSlots.maps:

            self.writeVint(EventSlots.maps.index(map) + 1)
            self.writeVint(EventSlots.maps.index(map) + 1)
            self.writeVint(map['Ended'])  # IsActive | 0 = Active, 1 = Disabled
            self.writeVint(EventSlots.Timer)  # Timer

            self.writeVint(0)
            self.writeScId(15, map['ID'])

            self.writeVint(map['Status'])

            self.writeString()
            self.writeVint(0)
            self.writeVint(0)  # Powerplay game played
            self.writeVint(0)  # Powerplay game left maximum

            if map['Modifier'] > 0:
                self.writeBoolean(True)  # Gamemodifier boolean
                self.writeVint(1)  # ModifierID
            else:
                self.writeBoolean(False)

            self.writeVint(0)
            self.writeVint(0)

        self.writeVint(0)  # array

        self.writeVint(8)
        self.writeVint(20)
        self.writeVint(35)
        self.writeVint(75)
        self.writeVint(140)
        self.writeVint(290)
        self.writeVint(480)
        self.writeVint(800)
        self.writeVint(1250)

        self.writeVint(8)
        self.writeVint(1)
        self.writeVint(2)
        self.writeVint(3)
        self.writeVint(4)
        self.writeVint(5)
        self.writeVint(10)
        self.writeVint(15)
        self.writeVint(20)

        self.writeVint(3)
        self.writeVint(10)
        self.writeVint(30)
        self.writeVint(80)

        self.writeVint(3)
        self.writeVint(6)
        self.writeVint(20)
        self.writeVint(60)

        coinpacks=json.load(open("coin_packs.json"))

        self.writeVint(len(coinpacks)) # How much coin packs?
        
        for pack in coinpacks:
            packk = coinpacks[pack]
            self.writeVint(packk["cost"])

        self.writeVint(len(coinpacks)) # how much coin packs?
        for pack in coinpacks:
            packk = coinpacks[pack]
            self.writeVint(packk["amount"])

        self.writeVint(0)
        self.writeVint(200)  # Max Tokens
        self.writeVint(0)  # Plus Tokens
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeBoolean(True)  # Box boolean

        self.writeVint(0)  # array

        self.writeVint(1)  # Menu Theme
        self.writeInt(1)
        #import random;self.player.theme = random.choice([LkPrtctrd for LkPrtctrd in range(15)])
        self.writeInt(41000000 + self.player.theme)  # Theme ID

        self.writeVint(0)  # array
        self.writeVint(0)  # array

        self.writeInt(self.player.high_id)
        self.writeInt(self.player.low_id)

        plrnotif = self.player.notifs

        self.writeVint(2 + len(plrnotif))  # array (and length of notifications)
        self.writeVint(81) #// FreeTextNotification
        self.writeInt(1) #// Notification Index
        self.writeBoolean(True) #// Read
        self.writeInt(0) # Time Ago
        self.writeString(f"Welcome To Pro Gamer Brawl v29!\nYour id: {self.player.low_id}\n<cfff200>M<cffe600>A<cffda00>K<cffce00>E<cffc200> <cffb600>S<cffa900>U<cff9d00>R<cff9100>E<cff8500> <cff7900>T<cff6d00>O<cff6100> <cff5400>C<cff4800>O<cff3c00>N<cff3000>N<cff2400>E<cff1800>C<cff0c00>T<cff0000> <cff000c>T<cff0018>O<cff0024> <cff0030>P<cff003c>R<cff0048>O<cff0055> <cff0061>G<cff006d>A<cff0079>M<cff0085>E<cff0091>R<cff009d> <cff00aa>B<cff00b6>R<cff00c2>A<cff00ce>W<cff00da>L<cff00e6> <cff00f2>I<cff00ff>D</c>")
        self.writeVint(1)#new notif
        
        for notiff in plrnotif:
            self.writeVint(notiff["ID"])
            self.writeInt(notiff["index"])
            self.writeBoolean(notiff["seen"])
            self.writeInt(int(time.time()) - notiff["ago"])
            self.writeString(notiff["msg"])
            if notiff["ID"] == 81:
                self.writeVint(1)
            if notiff["ID"] == 82 and "plr_name" in notiff and "plr_color" in notiff:
                self.writeString(notiff["plr_name"])
                self.writeVint(100)
                self.writeVint(28000000 + 6)
                self.writeVint(43000000 + notiff["plr_color"])
                self.writeVint(-1)
            if notiff["ID"] == 94 and "skin_id" in notiff:
                self.writeVint(29000000 + notiff["skin_id"])
            if notiff["ID"] == 89 and "gems" in notiff:
                self.writeVint(notiff["gems"])
                self.writeVint(1)


        
        self.writeVint(83)
        self.writeInt(0)
        self.writeBoolean(False) # True = no Popup # False = Popup
        self.writeInt(0)
        self.writeString("PGHGR")
        self.writeInt(0)
        self.writeString("Join our Telegram channel!")
        self.writeInt(0)
        self.writeString("Support us and don't miss out on exclusive events and news!")
        self.writeInt(0)
        self.writeString("JOIN")
        self.writeString("/CLy0fDNw/Untitled20-20251018181519.png")
        self.writeString('504735a82241393b50ddb2da054744e7172e5113')
        self.writeString("brawlstars://extlink?page=https%3A%2F%2Ft.me%2Fprogamerhacc")
        self.writeVint(3473)
		
        self.writeVint(0)
        self.writeBoolean(False)

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(self.player.high_id)  # High Id
        self.writeVint(self.player.low_id)  # Low Id

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)

        if self.player.name == "Guest":
            self.writeString("Guest")  # Player Name
            self.writeVint(0)
        else:
            if self.player.vip == 1:
                self.writeString(f"{self.player.name}")  # Player Name
            else:
                self.writeString(f"{self.player.name}")  # Player Name
            self.writeVint(1)

        self.writeInt(0)

        self.writeVint(8)

        # Unlocked Brawlers & Resources array
        self.writeVint(len(self.player.card_unlock_id) + 2)  # count

        index = 0
        for unlock_id in self.player.card_unlock_id:
            self.writeScId(23, unlock_id)
            try:
                self.writeVint(self.player.UnlockedBrawlers[str(index)])
            except:
                self.writeVint(1)
            index += 1

        self.writeVint(5)  # csv id
        self.writeVint(8)  # resource id
        self.writeVint(self.player.gold)  # resource amount

        self.writeVint(5)  # csv id
        self.writeVint(10)  # resource id
        self.writeVint(self.player.starpoints)  # resource amount

        # Brawlers Trophies array
        self.writeVint(len(self.player.brawlers_trophies))  # brawlers count
        for brawler_id, trophies in self.player.brawlers_trophies.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlers_trophies[f"{int(brawler_id)}"])

        # Brawlers Trophies for Rank array
        self.writeVint(len(self.player.brawlers_trophies))  # brawlers count
        for brawler_id, trophies in self.player.brawlers_trophies.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlers_trophies[f"{int(brawler_id)}"])

        self.writeVint(0)  # array

        # Brawlers Upgrade Points array
        self.writeVint(len(self.player.brawlerPoints))  # brawlers count
        for brawler_id, trophies in self.player.brawlerPoints.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlerPoints[f"{int(brawler_id)}"])

        # Brawlers Power Level array
        self.writeVint(len(self.player.brawlerPowerLevel))  # brawlers count
        for brawler_id, trophies in self.player.brawlerPowerLevel.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlerPowerLevel[f"{int(brawler_id)}"])

        spgList = []
        for brawler_id, level in self.player.brawlerPowerLevel.items():
            if level >= 8:
                unlocked_spg = Cards.get_spg_id(int(brawler_id))
                for spg_id in unlocked_spg:
                    if str(spg_id) in self.player.brawlers_spg_unlock:
                        if self.player.brawlers_spg_unlock[str(spg_id)] == 1:
                            spgList.append(spg_id)

        # Gadgets and Star Powers array
        self.writeVint(len(self.player.StarPowerUnlocked))
        for brawler_id, trophies in self.player.StarPowerUnlocked.items():
                self.writeScId(23, int(brawler_id))
                self.writeVint(self.player.StarPowerUnlocked[f"{int(brawler_id)}"])
                
        # "new" Brawler Tag array
        self.writeVint(0)  # brawlers count

        self.writeVint(self.player.gems)  # Player Gems
        self.writeVint(self.player.gems)
        self.writeVint(40)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(2)
        self.writeVint(1585502369)
        DataBase.replaceValue(self, 'online', 2)
        config = open('config.json', 'r')
        content = config.read()
        settings = json.loads(content)
        if self.player.gold < 0:
            self.player.gold = 0
            DataBase.replaceValue(self, 'gold', self.player.gold)
        if self.player.gems < 0:
            self.player.gems = 0
            DataBase.replaceValue(self, 'gems', self.player.gems)
        if self.player.vip == 0:
            if self.player.low_id in settings['vips']:
                DataBase.replaceValue(self, 'vip', 1)
        if self.player.low_id in settings['banID']:
            update_url = 'https://t.me/PROGamerHacc'
            self.player.err_code = 13
            LoginFailedMessage(self.client, self.player, '').send()
        BattleBan(self.client, self.player)
        """if self.player.name == "VBC26":
            #ну типо тут обнуление статистики если тебе надо секономить память дб
            update_url = 'https://t.me/ChromaticBrawl'
            self.player.err_code = 13
            LoginFailedMessage(self.client, self.player, "").send()
        BattleBan(self.client, self.player)"""
