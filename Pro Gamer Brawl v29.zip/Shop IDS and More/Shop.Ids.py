    << Shop Offers IDs List >>

    0 = Free Brawl Box
    1 = Gold
    2 = Random Brawler
    3 = Brawler
    4 = Skin
    5 = StarPower/ Gadget
    6 = Brawl Box
    7 = Tickets (not working anymore)
    8 = Power Points (for a specific brawler)
    9 = Token Doubler
    10 = Mega Box
    11 = Keys (???)
    12 = Power Points
    13 = EventSlot (???)
    14 = Big Box
    15 = AdBox (not working anymore)
    16 = Gems
    19 = Pin for Brawler
    20 = Pin Collection
    21 = Pin Pack
    22 = Pins Pack For Brawler
    23 = Pin Common (???)
    24 = Shop Skin Offer (May Not Work)
    94 = Skin???
    

    << Shop Offers BGR List >>

    Token Offer = offer_generic
    Special Offer = offer_special
    Starpoint Offer = offer_legendary
    Coin Offer = offer_coins(in v29 like offer_moon_festival)
    Gem Offer = offer_gems
    Box Offer = offer_boxes
    Brawler Offer = offer_finals
    LNY Offer = offer_lny
    Archive Offer = offer_archive
    Chromatic = offer_chromatic
    Moon Festival = offer_moon_festival
    Xmas = offer_xmas