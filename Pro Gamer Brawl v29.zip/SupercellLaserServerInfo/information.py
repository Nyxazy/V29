import pyfiglet
from termcolor import colored

class infolator():

	ascii_banner = pyfiglet.figlet_format("PGH\nBrawl")
	colored_banner = colored(ascii_banner, color='green')
	print(colored_banner)
	print("by ProGamerBrawlTeam\n")