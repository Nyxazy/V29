from scapy.all import sniff
import subprocess
import time

# Traffic limits
LIMIT_INCOMING_MB = 3  # Incoming limit in MB
LIMIT_OUTGOING_MB = 3  # Outgoing limit in MB
CHECK_INTERVAL = 2  # Check interval in seconds

incoming_traffic = {}
outgoing_traffic = {}
blocked_ips = set()

def monitor_packet(packet):
    if not packet.haslayer('IP'):
        return

    src_ip = packet['IP'].src
    dst_ip = packet['IP'].dst
    packet_size_mb = len(packet) / (1024 * 1024)  # размер пакета в МБ

    incoming_traffic[dst_ip] = incoming_traffic.get(dst_ip, 0) + packet_size_mb
    outgoing_traffic[src_ip] = outgoing_traffic.get(src_ip, 0) + packet_size_mb

def block_ip(ip):
    if ip not in blocked_ips:
        try:
            subprocess.run(["iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"], check=True)
            subprocess.run(["iptables", "-A", "OUTPUT", "-d", ip, "-j", "DROP"], check=True)
            blocked_ips.add(ip)
            print(f"[INFO] IP {ip} blocked due to exceeding the limit.")
        except subprocess.CalledProcessError as e:
            print(f"[ERROR] IP blocking error {ip}: {e}")

def check_traffic_limits():
    for ip, traffic in incoming_traffic.items():
        if traffic > LIMIT_INCOMING_MB:
            print(f"[INFO] Incoming traffic for {ip} exceeds the limit: {traffic:.2f} MB.")
            block_ip(ip)

    for ip, traffic in outgoing_traffic.items():
        if traffic > LIMIT_OUTGOING_MB:
            print(f"[INFO] Outgoing traffic for {ip} exceeds the limit: {traffic:.2f} MB.")
            block_ip(ip)

    incoming_traffic.clear()
    outgoing_traffic.clear()

def main():
    print("[INFO] Starting network monitoring...")
    while True:
        sniff(prn=monitor_packet, store=0, timeout=CHECK_INTERVAL)
        check_traffic_limits()
        total_incoming = sum(incoming_traffic.values())
        total_outgoing = sum(outgoing_traffic.values())
        print(f"[INFO] Current incoming traffic: {total_incoming:.2f} MB | Current outgoing traffic: {total_outgoing:.2f} MB")

        # Delay before next iteration
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    main()
