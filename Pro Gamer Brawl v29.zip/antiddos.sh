#!/bin/bash

# Parameters
IFACE="eth0"  # Please enter the name of your network interface.
LIMIT="50kbit"  # Speed Limit

# Remove all existing tc rules
tc qdisc del dev $IFACE root 2> /dev/null

# Adding a new rule to limit incoming traffic
tc qdisc add dev $IFACE root handle 1: htb default 12
tc class add dev $IFACE parent 1: classid 1:1 htb rate 1mbit
tc class add dev $IFACE parent 1:1 classid 1:12 htb rate $LIMIT ceil $LIMIT
