# batu :happi:

# reason why i created this: its for database issues; just run this and it will create a fresh empty database
print("DATABASE UPDATED")
import os
import sqlite3
if not os.path.exists("database/Player/plr.db"):
    os.makedirs("database/Player", exist_ok=True)
    conn = sqlite3.connect("database/Player/plr.db")
    conn.cursor().execute('''
        CREATE TABLE IF NOT EXISTS plrs (token TEXT, lowID INT, name TEXT, trophies INT, gold INT, gems INT, starpoints INT, tickets INT, Troproad INT, profile_icon INT, name_color INT,clubID INT, clubRole INT, brawlerData JSON, brawlerID INT, skinID INT, roomID INT, box INT, bigbox INT, online INT, vip INT, playerExp INT, friends JSON, SCC TEXT,trioWINS INT,sdWINS INT, theme INT, BPTOKEN INT, BPXP INT, quests JSON, freepass INT, buypass INT, notifRead INT, notifRead2 INT, ip_address TEXT, creation_date TEXT, Region TEXT, winstreak INT, highestwinstreak INT, notifs JSON, lastonline INT
        )
    ''')
    conn.commit()
    conn.close()