import telebot 
import random 
import json
import logging
import os
import sqlite3
import time
import re
import psutil
from core import Server

from quests import auto_quests


# создаем бота
admin=[5617592422]
bot = telebot.TeleBot('8009462504:AAG13eXAK9330rHJCnkVn5NI_0vFytPyUCE')

def dball():
    conn = sqlite3.connect("database/Player/plr.db")
    cur = conn.cursor()
    cur.execute("SELECT * FROM plrs")
    return cur.fetchall()

# Путь к файлу config.json
config_file_path = 'config.json'

def load_config():
    try:
        with open(config_file_path, 'r', encoding='utf-8') as file:
            config = json.load(file)
        return config
    except (FileNotFoundError, json.JSONDecodeError):
        return None

def save_config(config):
    try:
        with open(config_file_path, 'w', encoding='utf-8') as file:
            json.dump(config, file, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Произошла ошибка: {e}")
        return False

def update_maintenance_status(new_status):
    config = load_config()
    if config:
        config['maintenance'] = new_status
        return save_config(config)
    return False

def is_admin(user_id):
    return user_id in admin

# Функция для получения списка всех акций из файла offers.json
def get_offers():
    # Читаем данные из файла offers.json
    with open("JSON/offers.json", "r",encoding='utf-8') as f:
        data = json.load(f)

    # Генерируем текстовый список всех акци
    offer_list = "Список акций:\n"
    for offer_id, offer_data in data.items():
        vault=offer_data['ShopType']
        daily=offer_data['ShopDisplay']
        current=""
        types=""
        if vault==1:current="Золото"
        elif vault==0:current="Кристаллы"
        if daily==1:types="Ежедневная"
        elif daily==0:types="Обычная"
        offer_list += f"\nАкция #{offer_id}\n"
        offer_list += f"Название: {offer_data['OfferTitle']}\n"
        offer_list += f"Тип: {types}\n"
        offer_list += f"Боец: {offer_data['BrawlerID'][0]}\n"
        offer_list += f"Скин: {offer_data['SkinID'][0]}\n"
        offer_list += f"Валюта: {current}\n"
        offer_list += f"Стоимость: {offer_data['Cost']}\n"
        offer_list += f"Множитель: {offer_data['Multiplier'][0]}\n"

    # Возвращаем текстовый список всех акций
    return offer_list
# Обработчик команды /list
@bot.message_handler(commands=['list'])
def handle_list_offers(message):
    # Получаем список всех акций из файла offers.json
    offer_list = get_offers()

    # Отправляем пользователю список всех акций
    bot.send_message(chat_id=message.chat.id, text=offer_list)
    
    
@bot.message_handler(commands=['new_offer'])
def add_offer(message):
    user_id = message.from_user.id
    if user_id in admin:
    	if len(message.text.split()) < 2:
    	   bot.reply_to(message, 'Используйте команду /new_offer с аргументами в формате: /new_offer <ID> <OfferTitle> <Cost> <Multiplier> <BrawlerID> <SkinID> <OfferBGR> <ShopType> <ShopDisplay>')
    	   return
    	offer_data = message.text.split()
    	new_offer = {
            'ID': [int(offer_data[1]), 0, 0],
            'OfferTitle': offer_data[2],
            'Cost': int(offer_data[3]),
            'OldCost': 0,
            'Multiplier': [int(offer_data[4]), 0, 0],
            'BrawlerID': [int(offer_data[5]), 0, 0],
            'SkinID': [int(offer_data[6]), 0, 0],
            'WhoBuyed': [],
            'Timer': 86400,
            'OfferBGR': offer_data[7],
            'ShopType': int(offer_data[8]),
            'ShopDisplay': int(offer_data[9]),
            'ETType': 0,
            'ETMultiplier': 0,
            'OfferView': 0
    	}
    	with open('JSON/offers.json', 'r',encoding='utf-8') as f:
    	   offers = json.load(f)
    	offers[str(len(offers))] = new_offer
    	with open('JSON/offers.json', 'w',encoding='utf-8') as f:
    	   json.dump(offers, f, indent=4)
    	bot.reply_to(message, 'Новая акция добавлена!')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
@bot.message_handler(commands=['start'])
def send_welcome(message):
    user_id = message.from_user.id
    if user_id in admin:
    	bot.reply_to(message, "/status - Проверить статус сервера.\n/list - Посмотреть список акций.\n/new_offer - создает новую акцию.\n/remove_offer - Удалить акцию.\n/theme - Изменить всем фон\n/new_code - Добавить новый код Автора.\n/del_code - Удалить код Автора.\n/code_list - Список кодов Автора.\n/auto_shop - Обновить ежедневынй магазин.\n/enable_maintenance - Включить тех.перерыв.\n/disable_maintenance - Выключить тех.перерыв.\n/change_name - Изменить имя игроку.\n/add_vip - Выдать вип статус.\n/del_vip - Забрать вип статус.\n/add_gems - Выдать гемов игроку.\n/ban - Выдать бан игроку.\n/clear_room - Очистить румы в игре.\n/add_trophies - выдать трофеи игроку (не доведено до ума).\n/add_gold - Выдать монеты игроку.\n/add_star_points - Выдать ста проинты игроку\n/change_name_color\n/add_exp\n/change_profile_icon\n/add_sd_wins\n/new_reward_code\n/remove_reward_code\n/show_reward_codes\n/unlock_brawler\n/unlock_skin\n/delete_data\n/add_data\n/FetchID\n/reset_winstreak\n/reset_all_winstreak\n/generatecode\n/resetbp\n/resetseason\n/generatequests\n/new_notification_by_id\n/new_notification\n/change_role")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['change_name'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        parts = message.text.split(maxsplit=2)  # split only into 3 parts
        if len(parts) < 3:
            bot.reply_to(message, "Правильное использование: /set_name ID NEWNAME")
            return

        id = parts[1]
        new_name = parts[2]  # this keeps spaces if the name has them

        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE plrs SET name = ? WHERE lowID = ?", (new_name, id))
        conn.commit()
        conn.close()

        bot.send_message(chat_id=message.chat.id, text=f"Новое имя игрока {id}: {new_name}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
        
@bot.message_handler(commands=['remove_offer'])
def remove_offer(message):
    user_id = message.from_user.id
    if user_id in admin:
    	if len(message.text.split()) != 2:
    	   bot.reply_to(message, 'Используйте команду /remove_offer с аргументом в формате: /remove_offer <ID>')
    	   return
    	offer_id = message.text.split()[1]
    	with open('JSON/offers.json', 'r', encoding='utf-8') as f:
    		offers = json.load(f)
    	if offer_id not in offers:
    		bot.reply_to(message, f'Акция с ID {offer_id} не найдена')
    		return
    	offers.pop(offer_id)
    	with open('JSON/offers.json', 'w', encoding='utf-8') as f:
    		json.dump(offers, f)
    	bot.reply_to(message, f'Акция с ID {offer_id} удалена')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
# Определяем функцию-обработчик для команды /theme
@bot.message_handler(commands=['theme'])
def theme(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Выбери ID темы\n0 - Обычная\n1 - Новый год (Снег)\n2 - Красный новый год\n3 - От клеш рояля\n4 - Обычный фон с дефолт музыкой\n5 - Желтые панды\n7 - Роботы Зелёный фон\n8 - Хэллуин 2019\n9 - Пиратский фон (Новый год 2020)\n10 - Фон с обновы с мистером п.\n11 - Футбольный фон\n12 - Годовщина Supercell\n13 - Базар Тары\n14 - Лето с монстрами\nИспользовать команду /theme ID")
        else:
            user_id = message.from_user.id
            theme_id = message.text.split()[1]
            conn = sqlite3.connect("database/Player/plr.db")
            c = conn.cursor()
            c.execute(f"UPDATE plrs SET theme={theme_id}")
            conn.commit()
            c.execute("SELECT * FROM plrs")
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Айди всех записей был изменён на {theme_id}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
#коды автора
@bot.message_handler(commands=['new_code'])
def new_code(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /new_code Название Кода(На англ)")
        else:
            code = message.text.split()[1]
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if code not in config["CCC"]:
                config["CCC"].append(code)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Новый код {code}, Был добавлен!")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Код {code} уже существует!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['code_list'])
def code_list(message):
    with open('config.json', 'r') as f:
        data = json.load(f)
    code_list = '\n'.join(data["CCC"])
    bot.send_message(chat_id=message.chat.id, text=f"Список кодов: \n{code_list}")
    	
    	
@bot.message_handler(commands=['del_code'])
def del_code(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /del_code Название Кода")
        else:
            code = message.text.split()[1]
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if code in config["CCC"]:
                config["CCC"].remove(code)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Код {code}, Был удалён!")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Код {code} не найден!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
 #конец кодов
#Вип Старт
 
@bot.message_handler(commands=['add_vip'])
def add_vip(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_vip ID(Можно узнать в профиле профиле при поставке цветного ника)")
        else:
            vip_id = int(message.text.split()[1])
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if vip_id not in config["vips"]:
                config["vips"].append(vip_id)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Вип статус был выдан игроку с ID {vip_id}")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Вип статус уже есть у ID {vip_id}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

		
@bot.message_handler(commands=['del_vip'])
def del_vip(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /del_vip ID(Можно узнать в профиле профиле при поставке цветного ника)")
        else:
            code = int(message.text.split()[1])
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if code in config["vips"]:
                config["vips"].remove(code)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Вип статус был удален у игрока с ID {code}")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Вип статус не найден у игрока с ID {code}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")


#Конец випов
@bot.message_handler(commands=['auto_shop'])
def auto_shop(message):
    user_id = message.from_user.id
    if user_id in admin:
        with open('JSON/offers.json', 'r', encoding='utf-8') as f:
            data = json.load(f)
        for i in range(12): # изменяем первые 5 записей по ID
            if i <= 5:
                new_offer = {
                    'ID': [8, 0, 0],
                    'OfferTitle': "daily",
                    'Cost': random.randint(10, 228),
                    'OldCost': 0,
                    'Multiplier': [random.randint(1, 500), 0, 0],
                    'BrawlerID': [random.randint(1, 32), 0, 0],
                    'SkinID': [0, 0, 0],
                    'WhoBuyed': [],
                    'Timer': 86400,
                    'OfferBGR': "offer_gems",
                    'ShopType': 1,
                    'ShopDisplay': 1
                }
                
                skin_id = random.choice(get_skin_ids_by_rarity(rarity))
                new_offer['SkinID'] = [skin_id, 0, 0]
                data[i] = new_offer
            elif i > 5:
                with open('config.json', 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                skins = settings['Skinse']
                random_skin = random.choice(skins)
                settings['Skinse'] = skins
                with open('config.json', 'w', encoding='utf-8') as f:
                    json.dump(settings, f, indent=4, ensure_ascii=False)
                new_offer = {
                    'ID': [4, 0, 0],
                    'OfferTitle': "ЕЖЕДНЕВНЫЙ СКИН",
                    'Cost': 0,  # Добавляем поле Cost
                    'OldCost': 0,
                    'Multiplier': [0, 0, 0],
                    'BrawlerID': [0, 0, 0],
                    'SkinID': [random_skin, 0, 0],
                    'WhoBuyed': [],
                    'Timer': 86400,
                    'OfferBGR': "offer_gems",
                    'ShopType': 0,
                    'ShopDisplay': 0
                }
               
                
                skin_id = random.choice(get_skin_ids_by_rarity(rarity))
                new_offer['SkinID'] = [skin_id, 0, 0]
                data[i] = new_offer
        with open('JSON/offers.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        bot.reply_to(message, 'Акции успешно обновлены!')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

		
@bot.message_handler(commands=['add_gems'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        parts = message.text.split()
        if len(parts) < 3:
            bot.reply_to(message, "Правильное использование: /add_gems ID AMOUNT")
            return
        
        target_id = parts[1]
        try:
            add_amount = int(parts[2])
        except ValueError:
            bot.reply_to(message, "AMOUNT должен быть числом.")
            return

        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        
        # Get current gems
        cursor.execute("SELECT gems FROM plrs WHERE lowID = ?", (target_id,))
        result = cursor.fetchone()
        if result:
            current_gems = result[0]
            new_gems = current_gems + add_amount

            # Update gems
            cursor.execute("UPDATE plrs SET gems = ? WHERE lowID = ?", (new_gems, target_id))
            conn.commit()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {target_id} добавлено {add_amount} гемов (теперь у него {new_gems})")
        else:
            bot.reply_to(message, f"Игрок с ID {target_id} не найден.")
        
        conn.close()
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
		
@bot.message_handler(commands=['ban'])
def ban(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /ban ID")
        else:
            vip_id = int(message.text.split()[1])
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if vip_id not in config["banID"]:
                config["banID"].append(vip_id)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Бан был выдан игроку {vip_id}")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"Бан уже есть у игрока {vip_id}")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['unban'])
def ban(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /unban ID")
        else:
            vip_id = int(message.text.split()[1])
            with open("config.json", "r", encoding='utf-8') as f:
                config = json.load(f)
            if vip_id in config["banID"]:
                config["banID"].remove(vip_id)
                with open("config.json", "w", encoding='utf-8') as f:
                    json.dump(config, f, indent=4)
                bot.send_message(chat_id=message.chat.id, text=f"Разбан был выдан игроку {vip_id}")
            else:
                bot.send_message(chat_id=message.chat.id, text=f"У игрока {vip_id} отсутствует бан")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['clear_room'])
def clear_room(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            user_id = message.from_user.id
            plrsinfo = "database/Player/plr.db"
            if os.path.exists(plrsinfo):
                conn = sqlite3.connect("database/Player/plr.db")
                c = conn.cursor()
                c.execute("UPDATE plrs SET roomID=0")
                c.execute("SELECT * FROM plrs")
                conn.commit()
                conn.close()
                bot.reply_to(message, 'Команды были очищены!')
            else:
                bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_trophies'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_trophies ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET trophies = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Трофеев")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_gold'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        parts = message.text.split()
        if len(parts) < 3:
            bot.reply_to(message, "Правильное использование: /add_gold ID AMOUNT")
            return
        
        target_id = parts[1]
        try:
            add_amount = int(parts[2])
        except ValueError:
            bot.reply_to(message, "AMOUNT должен быть числом.")
            return

        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        
        # Get current gems
        cursor.execute("SELECT gold FROM plrs WHERE lowID = ?", (target_id,))
        result = cursor.fetchone()
        if result:
            current_gems = result[0]
            new_gems = current_gems + add_amount

            # Update gems
            cursor.execute("UPDATE plrs SET gold = ? WHERE lowID = ?", (new_gems, target_id))
            conn.commit()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {target_id} добавлено {add_amount} гемов (теперь у него {new_gems})")
        else:
            bot.reply_to(message, f"Игрок с ID {target_id} не найден.")
        
        conn.close()
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Команда для обновления значения maintenance на true
@bot.message_handler(commands=['enable_maintenance'])
def enable_maintenance(message):
    if is_admin(message.from_user.id):
        if update_maintenance_status(True):
            bot.reply_to(message, "Технический перерыв был включен!")
        else:
            bot.reply_to(message, "Произошла ошибка при включении технического перерыва.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

# Команда для обновления значения maintenance на false
@bot.message_handler(commands=['disable_maintenance'])
def disable_maintenance(message):
    if is_admin(message.from_user.id):
        if update_maintenance_status(False):
            bot.reply_to(message, "Технический перерыв был выключен!")
        else:
            bot.reply_to(message, "Произошла ошибка при выключении технического перерыва.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['status'])
def status(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            user_id = message.from_user.id
            with open('config.json', 'r') as f:
                data = json.load(f)
                ban_list = len(data["banID"])
                vip_list = len(data["vips"])
            player_list = len(dball())
            bot.reply_to(message, f'Всего создано аккаунтов: {player_list}\nИгроков в бане: {ban_list}\nИгроков с вип: {vip_list}\n\nRAM: {psutil.virtual_memory().percent}%\nCPU: {psutil.cpu_percent()}%')
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
        
        
@bot.message_handler(commands=['add_star_points'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        parts = message.text.split()
        if len(parts) < 3:
            bot.reply_to(message, "Правильное использование: /add_starpoints ID AMOUNT")
            return
        
        target_id = parts[1]
        try:
            add_amount = int(parts[2])
        except ValueError:
            bot.reply_to(message, "AMOUNT должен быть числом.")
            return

        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        
        # Get current gems
        cursor.execute("SELECT playerExp FROM plrs WHERE lowID = ?", (target_id,))
        result = cursor.fetchone()
        if result:
            current_gems = result[0]
            new_gems = current_gems + add_amount

            # Update gems
            cursor.execute("UPDATE plrs SET playerExp = ? WHERE lowID = ?", (new_gems, target_id))
            conn.commit()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {target_id} добавлено {add_amount} гемов (теперь у него {new_gems})")
        else:
            bot.reply_to(message, f"Игрок с ID {target_id} не найден.")
        
        conn.close()
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")
        
@bot.message_handler(commands=['change_profile_icon'])
def change_name(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /change_profile_icon ID AMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET profile_icon = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} изменили имя на {ammount}.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")        
        
@bot.message_handler(commands=['change_name_color'])
def change_name(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /change_name_color ID AMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET name_color = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} изменили имя на {ammount}.")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")   

@bot.message_handler(commands=['add_exp'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_exp ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET playerExp = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Монет!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['add_sd_wins'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_sd_wins ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET sdWINS = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Монет!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['print_usernames'])
def print_usernames(message):
    user_id = message.from_user.id
    if user_id in admin:
        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        cursor.execute("SELECT lowID, name FROM plrs")
        all_players = cursor.fetchall()
        conn.close()

        player_list = ""
        for lowID, name in all_players:
            clean_name = ''.join(c for c in name if 32 <= ord(c) <= 126)
            player_list += f"{lowID} | {clean_name}\n"

        if player_list.strip() == "":
            bot.send_message(chat_id=message.chat.id, text="No players found in database.")
        else:
            bot.send_message(chat_id=message.chat.id, text=f"All Players:\n{player_list}")
    else:
        bot.reply_to(message, "You are not admin!")

@bot.message_handler(commands=['unlock_brawler'])
def unlock_brawler(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Command usage: /unlock_brawler <ID> <BRAWLER_ID 0-38>")
        else:
            id = message.text.split()[1]
            brawler_id = int(message.text.split()[2])
            if not (0 <= brawler_id <= 101):
                bot.reply_to(message, "BRAWLER_ID must be between 0 and 38.")
                return

            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()

            cursor.execute("SELECT brawlerData FROM plrs WHERE lowID = ?", (id,))
            result = cursor.fetchone()
            if not result:
                bot.reply_to(message, "Player not found.")
                conn.close()
                return

            data = json.loads(result[0])
            if str(brawler_id) in data["UnlockedBrawlers"] and data["UnlockedBrawlers"][str(brawler_id)] == 1:
                bot.send_message(chat_id=message.chat.id, text=f"Brawler ID {brawler_id} is already unlocked for ID: {id}.")
            else:
                data["UnlockedBrawlers"][str(brawler_id)] = 1
                cursor.execute("UPDATE plrs SET brawlerData = ? WHERE lowID = ?", (json.dumps(data), id))
                conn.commit()
                bot.send_message(chat_id=message.chat.id, text=f"Unlocked Brawler ID {brawler_id} for player ID {id}.")
            conn.close()
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['unlock_skin'])
def unlock_skin(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 3:
            bot.reply_to(message, "Command usage: /unlock_skin <ID> <SKIN_ID>")
        else:
            id = message.text.split()[1]
            skin_id = message.text.split()[2]

            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("SELECT brawlerData FROM plrs WHERE lowID = ?", (id,))
            result = cursor.fetchone()

            if not result:
                bot.reply_to(message, "Player not found.")
                conn.close()
                return

            data = json.loads(result[0])
            unlocked_skins = data.get("UnlockedSkins", {})

            if skin_id in unlocked_skins and unlocked_skins[skin_id] == 1:
                bot.send_message(chat_id=message.chat.id, text=f"Skin ID {skin_id} is already unlocked for ID: {id}.")
            else:
                unlocked_skins[skin_id] = 1
                data["UnlockedSkins"] = unlocked_skins
                cursor.execute("UPDATE plrs SET brawlerData = ? WHERE lowID = ?", (json.dumps(data), id))
                conn.commit()
                bot.send_message(chat_id=message.chat.id, text=f"Unlocked Skin ID {skin_id} for player ID {id}.")
            conn.close()
    else:
        bot.reply_to(message, "You are not admin!")
        
        
@bot.message_handler(commands=['unlockBrawlers'])
def unlock_brawlers(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()
        if len(args) < 2:
            bot.reply_to(message, "Usage: /unlockBrawlers <PLAYER_ID>")
            return

        player_id = args[1]
        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        cursor.execute("SELECT brawlerData FROM plrs WHERE lowID = ?", (player_id,))
        result = cursor.fetchone()

        if not result:
            bot.reply_to(message, "Player not found.")
            conn.close()
            return

        data = json.loads(result[0])
        unlocked = data.get("UnlockedBrawlers", {})

        for i in range(0, 39):
            unlocked[str(i)] = 1

        data["UnlockedBrawlers"] = unlocked
        cursor.execute("UPDATE plrs SET brawlerData = ? WHERE lowID = ?", (json.dumps(data), player_id))
        conn.commit()
        conn.close()
        bot.send_message(message.chat.id, f"All brawlers unlocked for ID {player_id}.")
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['unlockSkins'])
def unlock_skins(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()
        if len(args) < 2:
            bot.reply_to(message, "Usage: /unlockSkins <PLAYER_ID>")
            return

        player_id = args[1]
        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        cursor.execute("SELECT brawlerData FROM plrs WHERE lowID = ?", (player_id,))
        result = cursor.fetchone()

        if not result:
            bot.reply_to(message, "Player not found.")
            conn.close()
            return

        data = json.loads(result[0])
        unlocked = data.get("UnlockedSkins", {})

        for i in range(0, 501):
            unlocked[str(i)] = 1

        data["UnlockedSkins"] = unlocked
        cursor.execute("UPDATE plrs SET brawlerData = ? WHERE lowID = ?", (json.dumps(data), player_id))
        conn.commit()
        conn.close()
        bot.send_message(message.chat.id, f"All skins unlocked for ID {player_id}.")
    else:
        bot.reply_to(message, "You are not admin!")

@bot.message_handler(commands=['delete_data'])
def delete_data(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()[1:]
        if not args:
            bot.reply_to(message, "Usage: /delete_data <NAME> <NAME> ...")
            return

        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()

        deleted_names = []

        for name in args:
            cursor.execute("DELETE FROM plrs WHERE name = ?", (name,))
            if cursor.rowcount > 0:
                deleted_names.append(name)

        conn.commit()
        conn.close()

        if deleted_names:
            bot.send_message(chat_id=message.chat.id, text=f"Deleted users: {', '.join(deleted_names)}")
        else:
            bot.send_message(chat_id=message.chat.id, text="No users found with the given names.")
    else:
        bot.reply_to(message, "You are not admin!")

@bot.message_handler(commands=['reset_winstreak'])
def reset_winstreak(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()
        if len(args) < 2:
            bot.reply_to(message, "Command usage: /reset_winstreak <ID>")
        else:
            target_id = args[1]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET winstreak = 0 WHERE lowID = ?", (target_id,))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Successfully reset winstreak for ID: {target_id}")
    else:
        bot.reply_to(message, "You are not admin!")

@bot.message_handler(commands=['reset_all_winstreak'])
def reset_all_winstreak(message):
    user_id = message.from_user.id
    if user_id in admin:
        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        cursor.execute("UPDATE plrs SET winstreak = 0")
        conn.commit()
        conn.close()
        bot.send_message(chat_id=message.chat.id, text="Successfully reset winstreak for all players to 0.")
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['FetchID'])
def FetchID(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.strip().split()
        if len(args) < 2:
            bot.reply_to(message, "Usage: /FetchID #TAG")
            return

        tag = args[1]

        TagChar = ("0", "2", "8", "9", "P", "Y", "L", "Q", "G", "R", "J", "C", "U", "V")
        if not tag.startswith('#'):
            bot.reply_to(message, "Wrong Hashtag!")
            return

        TagArray = list(tag[1:].upper())
        Id = 0
        for ch in TagArray:
            try:
                CharIndex = TagChar.index(ch)
            except ValueError:
                bot.reply_to(message, 'Wrong Hashtag : should only contain "0", "2", "8", "9", "P", "Y", "L", "Q", "G", "R", "J", "C", "U" or "V"')
                return
            Id *= len(TagChar)
            Id += CharIndex

        HighLow = []
        HighLow.append(Id % 256)
        HighLow.append((Id - HighLow[0]) >> 8)

        bot.reply_to(message, f"Id = {Id}\nHighLowId = {HighLow[0]}-{HighLow[1]}")
    else:
        bot.reply_to(message, "You are not admin!")
        

@bot.message_handler(commands=['ViewInfo'])
def ViewInfo(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()
        if len(args) < 2:
            bot.reply_to(message, "Command usage: /ViewInfo <ID>")
            return

        target_id = args[1]
        conn = sqlite3.connect("database/Player/plr.db")
        cursor = conn.cursor()
        cursor.execute(
            "SELECT lowID, name, trophies, gems, gold, winstreak, highestwinstreak, token FROM plrs WHERE lowID = ?",
            (target_id,)
        )
        row = cursor.fetchone()
        conn.close()

        if row:
            lowID, name, trophies, gems, gold, winstreak, highestwinstreak, token = row

            msg = (
                f"Player Info\n"
                f"ID: {lowID}\n"
                f"Name: {name}\n"
                f"Trophies: {trophies}\n"
                f"Gems: {gems}\n"
                f"Gold: {gold}\n"
                f"Current Winstreak: {winstreak}\n"
                f"Highest Winstreak: {highestwinstreak}\n"
                f"Token: {token}"
            )
            bot.send_message(chat_id=message.chat.id, text=msg)
        else:
            bot.send_message(chat_id=message.chat.id, text=f"No player found with ID {target_id}")
    else:
        bot.reply_to(message, "You are not admin!")

@bot.message_handler(commands=['transfer'])
def transfer_data(message):
    if message.from_user.id not in admin:
        return

    args = message.text.strip().split()
    if len(args) != 3:
        bot.reply_to(message, "Usage: /transfer <loginnerID> <transferedID>")
        return

    loginner_id = args[1]
    transfered_id = args[2]

    conn = sqlite3.connect("database/Player/plr.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM plrs WHERE lowID = ?", (loginner_id,))
    loginner = cursor.fetchone()

    cursor.execute("SELECT * FROM plrs WHERE lowID = ?", (transfered_id,))
    transfered = cursor.fetchone()

    if not loginner:
        bot.reply_to(message, f"loginnerID {loginner_id} not found.")
        conn.close()
        return

    if not transfered:
        bot.reply_to(message, f"transferedID {transfered_id} not found.")
        conn.close()
        return

    cursor.execute("PRAGMA table_info(plrs)")
    columns_info = cursor.fetchall()
    all_columns = [col[1] for col in columns_info]

    loginner_data = dict(zip(all_columns, loginner))
    transfered_data = dict(zip(all_columns, transfered))

    transfered_data["token"] = loginner_data["token"]

    transfered_data["lowID"] = int(loginner_id)

    cursor.execute("DELETE FROM plrs WHERE lowID = ?", (loginner_id,))

    placeholders = ", ".join(["?"] * len(all_columns))
    insert_query = f"INSERT INTO plrs ({', '.join(all_columns)}) VALUES ({placeholders})"
    cursor.execute(insert_query, [transfered_data[col] for col in all_columns])

    cursor.execute("DELETE FROM plrs WHERE lowID = ?", (transfered_id,))
    conn.commit()
    conn.close()

    bot.send_message(message.chat.id, f" Data from {transfered_id} successfully moved to {loginner_id}! Also old account is deleted.")

@bot.message_handler(commands=['add_data'])
def add_data(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()
        if len(args) < 2:
            bot.reply_to(message, "Command usage: /add_data <Data Name> <Value>")
            return

        data_name = args[1]
        default_value = 0
        if len(args) >= 3:
            try:
                default_value = int(args[2])
            except ValueError:
                bot.reply_to(message, "Default value must be a number.")
                return

        try:
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            try:
                cursor.execute(f"ALTER TABLE plrs ADD COLUMN {data_name} INTEGER DEFAULT {default_value}")
            except sqlite3.OperationalError:
                pass
            cursor.execute(f"UPDATE plrs SET {data_name} = ?", (default_value,))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id,
                             text=f" Sucessfully added data '{data_name}' with default value {default_value} for all players")
        except Exception as e:
            bot.send_message(chat_id=message.chat.id, text=f"Error: {e}")
    else:
        bot.reply_to(message, "You are not admin!")

@bot.message_handler(commands=['generatecode'])
def generate_codes(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text.split()
        if len(args) < 3:
            bot.reply_to(message, "Command usage: /generatecode <HowMuch> <TimeInSeconds>")
            return

        how_many = args[1]
        expire_time = args[2]

        if not how_many.isdigit() or not expire_time.isdigit():
            bot.reply_to(message, "Please enter numbers only.")
            return

        how_many = int(how_many)
        expire_time = int(expire_time)

        codes = []
        for _ in range(how_many):
            code = f"{random.randint(0,99):02}-{random.randint(0,999):03}-{random.randint(0,9999):04}-{random.randint(0,9)}"
            codes.append([code, expire_time])

        try:
            with open("vip_codes.json", "r") as f:
                data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            data = []

        data.extend(codes)

        with open("vip_codes.json", "w") as f:
            json.dump(data, f, indent=4)

        bot.send_message(
            chat_id=message.chat.id,
            text="\n".join([f"`{c[0]}` (expires in {c[1]}s)" for c in codes]),
            parse_mode='Markdown'
        )
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['add_trio_wins'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Правильное использование /add_sd_wins ID AMMOUNT")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET trioWINS = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"Игроку с айди {id} Выдали {ammount} Монет!")
    else:
        bot.reply_to(message, "Вы не являетесь администратором!")

@bot.message_handler(commands=['new_reward_code'])
def new_reward_code(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, 'Command usage: /new_reward_code <Code Name> <Reward (gem, gold, skin, brawler, pin, pinpack, megabox, normalbox, smallbox)> <Multiplier>')
            return
        code_data = message.text.split()
        
        with open('ccc_codes.json', 'r', encoding='utf-8') as f:
            codes = json.load(f)
            if code_data[1] in codes['codes']:
                bot.reply_to(message, f'There is already a CCC code reward named {code_data[1]}!')
                return
        
            if code_data[2] == "pinpack":
                codes['codes'][code_data[1]] = {
                "SETTINGS": {
                    "Reward": "pinpack",
                    "Multiplier": "batu batu batu" 
                },
                "whogot": []
            }
            else:
                codes['codes'][code_data[1]] = {
                    "SETTINGS": {
                        "Reward": code_data[2],
                        "Multiplier": code_data[3]
                    },
                    "whogot": []
                }
            with open('ccc_codes.json', 'w', encoding='utf-8') as f:
                json.dump(codes, f, indent=4)
                bot.reply_to(message, f'Successfully added {code_data[1]} as a CCC code reward!')
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['remove_reward_code'])
def remove_reward_code(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, 'Command usage: /remove_reward_code <Code Name>')
            return
        code_data = message.text.split()
        
        with open('ccc_codes.json', 'r', encoding='utf-8') as f:
            codes = json.load(f)
            if code_data[1] not in codes['codes']:
                bot.reply_to(message, f'There is no CCC called {code_data[1]} in CCC reward codes!')
                return
        
            del codes['codes'][code_data[1]]
            with open('ccc_codes.json', 'w', encoding='utf-8') as f:
                json.dump(codes, f, indent=4)
                bot.reply_to(message, f'Successfully removed {code_data[1]} from CCC code rewards!')
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['show_reward_codes'])
def show_reward_codes(message):
    user_id = message.from_user.id
    if user_id in admin:
        bot.send_message(chat_id=message.chat.id, text=getcccrewards())
    else:
        bot.reply_to(message, "You are not admin!")       
        
@bot.message_handler(commands=['resetseason'])

def reset_brawl_pass(message):

    user_id = message.from_user.id

    if user_id not in admin:

        bot.send_message(message.chat.id, "nigga, youre not an admin")

        return

    try:

        # Convert lists to JSON strings

        freepass_data = json.dumps([])

        buypass_data = json.dumps([])

        

        # Reset Brawl Pass for all players in the database

        with sqlite3.connect('database/Player/plr.db') as server_db_connection:

            server_db_cursor = server_db_connection.cursor()

            # Update the Brawl Pass data for all accounts

            server_db_cursor.execute("UPDATE plrs SET freepass = ?, buypass = ?, BPTOKEN = ?", 

                                      (freepass_data, buypass_data, 0))

            server_db_connection.commit()

            bot.send_message(message.chat.id, "ok, i resetted season")

    except Exception as e:

        logger.error(f"Error in /resetbp command: {e}")

        bot.send_message(message.chat.id, f"An error occurred: {str(e)}")

@bot.message_handler(commands=['resetbp'])
def reset_brawl_pass(message):
    user_id = message.from_user.id
    
    if user_id not in admin:
        bot.send_message(message.chat.id, "❌ Вы не являетесь администратором!")
        return
    
    # Extract lowID from arguments
    args = message.text.split()
    if len(args) != 2:
        bot.send_message(message.chat.id, "❌ Используйте команду в формате: /resetbp [lowID]")
        return

    try:
        lowID = int(args[1])
    except ValueError:
        bot.send_message(message.chat.id, "❌ Неверный формат lowID. Убедитесь, что вы вводите число.")
        return

    try:
        # Convert lists to JSON strings
        freepass_data = json.dumps([])
        buypass_data = json.dumps([])
        
        # Reset Brawl Pass in the database
        with sqlite3.connect('database/Player/plr.db') as server_db_connection:
            server_db_cursor = server_db_connection.cursor()

            # Update the player's Brawl Pass data
            server_db_cursor.execute("UPDATE plrs SET freepass = ?, buypass = ?, BPTOKEN = ? WHERE lowID = ?", 
                                    (freepass_data, buypass_data, 0, lowID))
            server_db_connection.commit()

            bot.send_message(message.chat.id, f"✅ Brawl Pass для аккаунта с ID {lowID} успешно сброшен.")
    except Exception as e:
        logger.error(f"Error in /resetbp command: {e}")
        bot.send_message(message.chat.id, f"❌ Произошла ошибка: {str(e)}")

@bot.message_handler(commands=['new_notification'])
def new_notification(message):
    user_id = message.from_user.id
    if user_id in admin:
        notifss = {
            "Announcement": 81,
            "Gems": 89,
            "Skin": 94
        }
        splited = message.text[len("/new_notification "):].strip()
        matc = re.match(r'<?(\w+)>? "(.*)" (\d+)', splited)
        if not matc:
            bot.reply_to(message, "Usage: /new_notification <type (Announcement, Gems, Skin)>, '<text'>, <multiplier>")
            return
            
        notiftype, notifname, multi = matc.groups()
        if notiftype not in ["Announcement", "Gems", "Skin"]:
            bot.reply_to(message, "wrong data type")
            return
            
        notifid = notifss[notiftype]
        multip = int(multi) if multi else 0
        
        conn = sqlite3.connect("database/Player/plr.db")
        cur = conn.cursor()
        cur.execute("SELECT lowID, notifs FROM plrs")
        all_players = cur.fetchall()
        
        for low_id, notifs in all_players:
            notiffs = json.loads(notifs)
            notif = {
                "ID": notifid,
                "index": random.randint(1, 999999999),
                "seen": False,
                "ago": int(time.time()),
                "msg": f"{notifname}",
                "msg_TYPE": 1,
            }
            if notifid == 89:
                notif["gems"] = multip
            elif notifid == 94:
                notif["skin_id"] = multip
            notiffs.append(notif)
            cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?", (json.dumps(notiffs), low_id))
        conn.commit()
        conn.close()
        bot.reply_to(message, "Sucessfully putted the notification!!!")
    else:
        bot.reply_to(message, "You are not admin!")
        
@bot.message_handler(commands=['new_notification_by_id'])
def new_notification_by_id(message):
    user_id = message.from_user.id
    if user_id in admin:
        args = message.text[len("/new_notification_by_id "):].strip()
        match = re.match(r'(\d+)\s+(\w+)\s+"([^"]+)"(?:\s+(\d+))?$', args)

        if not match:
            bot.reply_to(message, 'Usage: /new_notification_by_id <low_id> <type> "<text>" <multiplier>')
            return

        low_id, notiftype, notiftext, multiplier = match.groups()
        low_id = int(low_id)
        multiplier = int(multiplier) if multiplier else 0

        valid_types = ["Announcement", "Gems", "Skin"]
        if notiftype not in valid_types:
            bot.reply_to(message, f"Invalid type! Use one of: {', '.join(valid_types)}")
            return

        conn = sqlite3.connect("database/Player/plr.db")
        cur = conn.cursor()
        cur.execute("SELECT notifs FROM plrs WHERE lowID = ?", (low_id,))
        result = cur.fetchone()

        if not result:
            bot.reply_to(message, f"Player with ID {low_id} not found!")
            conn.close()
            return

        current_notifs = json.loads(result[0]) if result[0] else []

        new_notif = {
            "ID": 81 if notiftype == "Announcement" else 89 if notiftype == "Gems" else 94, # why im even using new smart format here?
            "index": random.randint(1, 999999999),
            "seen": False,
            "ago": int(time.time()),
            "msg": f"{notiftext}",
            "msg_TYPE": 1
        }

        if notiftype == "Gems":
            new_notif["gems"] = multiplier
        elif notiftype == "Skin":
            new_notif["skin_id"] = multiplier

        current_notifs.append(new_notif)
        cur.execute("UPDATE plrs SET notifs = ? WHERE lowID = ?", (json.dumps(current_notifs), low_id))
        conn.commit()
        conn.close()

        bot.reply_to(message, f"Successfully sent notification to low ID {low_id}!")
    else:
        bot.reply_to(message, "You are not admin!")
        return            
@bot.message_handler(commands=['change_role'])
def add_gems(message):
    user_id = message.from_user.id
    if user_id in admin:
        if len(message.text.split()) < 2:
            bot.reply_to(message, "Correct usage: /change_role (id) (role id)\n0 = Nothing, 1 = Member, 2 = President, 3 = Senior, 4 = Vice President")
        else:
            user_id = message.from_user.id
            id = message.text.split()[1]
            ammount = message.text.split()[2]
            conn = sqlite3.connect("database/Player/plr.db")
            cursor = conn.cursor()
            cursor.execute("UPDATE plrs SET clubRole = ? WHERE lowID = ?", (ammount, id))
            conn.commit()
            conn.close()
            bot.send_message(chat_id=message.chat.id, text=f"changed role successfully on id: {id}")
    else:
        bot.reply_to(message, "You are not an administrator!")              
if __name__ == "__main__":
    bot.infinity_polling()