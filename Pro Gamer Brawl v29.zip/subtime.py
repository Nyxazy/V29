#!/usr/bin/env python3
import json
import os
import sys
import tempfile
import time
import signal

fname = "vip_codes.json"

def ensure_file(path):
    if not os.path.exists(path) or os.stat(path).st_size == 0:
        with open(path, "w", encoding="utf-8") as f:
            json.dump([], f)

def loadcodes(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []

    normalized = []
    if isinstance(data, dict):
        for k, v in data.items():
            try:
                remaining = int(v)
            except Exception:
                continue
            normalized.append([str(k), remaining])
    elif isinstance(data, list):
        for entry in data:
            if isinstance(entry, list) and len(entry) >= 2:
                code = str(entry[0])
                try:
                    remaining = int(entry[1])
                except Exception:
                    continue
                normalized.append([code, remaining])
            elif isinstance(entry, dict) and "code" in entry and "remaining" in entry:
                try:
                    remaining = int(entry["remaining"])
                except Exception:
                    continue
                normalized.append([str(entry["code"]), remaining])
    return normalized

def wcodesato(path, data):
    dirpath = os.path.dirname(os.path.abspath(path)) or "."
    os.makedirs(dirpath, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", delete=False, dir=dirpath, encoding="utf-8") as tmpf:
        json.dump(data, tmpf, indent=4, ensure_ascii=False)
        tmpname = tmpf.name
    os.replace(tmpname, path)

def pro(path):
    codes = loadcodes(path)
    new_codes = []
    for code, remaining in codes:
        try:
            remaining = int(remaining)
        except Exception:
            continue
        remaining -= 1
        if remaining > 0:
            new_codes.append([code, remaining])
    wcodesato(path, new_codes)

def main():
    ensure_file(fname)

    def _on_signal(signum, frame):
        sys.exit(0)

    signal.signal(signal.SIGINT, _on_signal)
    signal.signal(signal.SIGTERM, _on_signal)

    try:
        while True:
            pro(fname)
            time.sleep(1)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
